import { useEffect, useState, type ReactNode, type RefObject } from 'react';
import { BIKES, POWERS, type BikeDef, type PowerKind, type TimePref } from '../game/config';
import type { RunStats } from '../game/Engine';
import type { SaveData, ScoreEntry } from '../game/storage';

export const isTouch = typeof window !== 'undefined' && ('ontouchstart' in window || navigator.maxTouchPoints > 0);

export function Btn({
  children,
  onClick,
  color = '#22f3ff',
  primary,
  className = '',
  disabled,
}: {
  children: ReactNode;
  onClick: () => void;
  color?: string;
  primary?: boolean;
  className?: string;
  disabled?: boolean;
}) {
  return (
    <button
      disabled={disabled}
      onClick={onClick}
      className={`btn-neon ${primary ? 'btn-primary' : ''} px-6 py-3 text-sm sm:text-base font-bold tracking-widest uppercase disabled:opacity-40 disabled:cursor-not-allowed ${className}`}
      style={{ ['--c' as string]: color }}
    >
      {children}
    </button>
  );
}

function CoinIcon({ size = 18 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" className="inline-block drop-shadow-[0_0_6px_#ffd23f]">
      <polygon points="12,1 22,6.5 22,17.5 12,23 2,17.5 2,6.5" fill="#ffd23f" stroke="#fff3b0" strokeWidth="1.5" />
      <path d="M13 5 L8 13 H12 L11 19 L16 10 H12 Z" fill="#6b3a00" />
    </svg>
  );
}

export function Bank({ amount }: { amount: number }) {
  return (
    <div className="flex items-center gap-2 font-display text-lg font-bold text-[#ffd23f] neon-text">
      <CoinIcon size={20} />
      {amount.toLocaleString()}
    </div>
  );
}

const TIMES: { id: TimePref; label: string; icon: string }[] = [
  { id: 'day', label: 'DAY', icon: '☀' },
  { id: 'cycle', label: 'CYCLE', icon: '◐' },
  { id: 'night', label: 'NIGHT', icon: '☾' },
];

export function TimeToggle({ value, onChange }: { value: TimePref; onChange: (t: TimePref) => void }) {
  return (
    <div className="pointer-events-auto flex items-center border border-cyan-300/35 bg-black/50 overflow-hidden">
      {TIMES.map((t) => (
        <button
          key={t.id}
          onClick={() => onChange(t.id)}
          className={`px-2.5 py-2 font-display text-[10px] sm:text-[11px] font-bold tracking-widest transition ${
            value === t.id ? 'bg-cyan-300/25 text-white' : 'text-white/45 hover:text-white/80'
          }`}
          style={value === t.id ? { textShadow: '0 0 10px #22f3ff' } : undefined}
          title={`${t.label} lighting`}
        >
          <span className="mr-1">{t.icon}</span>
          {t.label}
        </button>
      ))}
    </div>
  );
}

export function MuteBtn({ muted, onToggle }: { muted: boolean; onToggle: () => void }) {
  return (
    <button
      onClick={onToggle}
      className="pointer-events-auto w-11 h-11 grid place-items-center rounded-md border border-cyan-300/40 bg-black/40 text-xl hover:bg-cyan-400/20 transition"
      aria-label="Toggle sound"
    >
      {muted ? '🔇' : '🔊'}
    </button>
  );
}

// ---------------- Title ----------------
export function TitleScreen({
  save,
  onStart,
  onGarage,
  onScores,
  onName,
  onMute,
  onTime,
}: {
  save: SaveData;
  onStart: () => void;
  onGarage: () => void;
  onScores: () => void;
  onName: (n: string) => void;
  onMute: () => void;
  onTime: (t: TimePref) => void;
}) {
  const best = save.scores[0]?.score ?? 0;
  return (
    <div className="absolute inset-0 flex flex-col items-center justify-between p-4 sm:p-8 pointer-events-none">
      <div className="scrim-top absolute top-0 inset-x-0 h-56 -z-10" />
      <div
        className="absolute bottom-0 inset-x-0 h-2/3 -z-10"
        style={{ background: 'linear-gradient(0deg, rgba(4,2,12,0.88) 0%, rgba(4,2,12,0.5) 45%, transparent 100%)' }}
      />
      <div className="w-full flex justify-between items-center gap-2 pointer-events-auto">
        <Bank amount={save.bank} />
        <div className="flex items-center gap-2">
          <TimeToggle value={save.time} onChange={onTime} />
          <MuteBtn muted={save.muted} onToggle={onMute} />
        </div>
      </div>

      <div className="text-center fade-in mt-2">
        <div className="font-display text-[11px] sm:text-sm tracking-[0.5em] text-pink-300/90 mb-2 neon-text">// NEO-TOKYO GRID 2099 //</div>
        <h1 className="title-main glitch text-5xl sm:text-7xl md:text-8xl" data-text="NEON BIKE">
          NEON BIKE
        </h1>
        <h1 className="title-main glitch text-5xl sm:text-7xl md:text-8xl" data-text="ESCAPE">
          ESCAPE
        </h1>
        {best > 0 && (
          <div className="mt-3 font-display text-sm text-cyan-200/90 tracking-widest">
            BEST <span className="text-white font-bold neon-text">{best.toLocaleString()}</span>
          </div>
        )}
      </div>

      <div className="flex-1" />

      <div className="flex flex-col items-center gap-3 w-full max-w-sm pointer-events-auto fade-in" style={{ animationDelay: '0.15s' }}>
        <div className="flex items-center gap-2 w-full">
          <span className="font-display text-xs tracking-widest text-cyan-200/80">PILOT</span>
          <input
            className="name-input flex-1 px-3 py-2 text-sm tracking-widest uppercase"
            maxLength={10}
            value={save.name}
            onChange={(e) => onName(e.target.value.toUpperCase().replace(/[^A-Z0-9 _-]/g, ''))}
            onKeyDown={(e) => e.stopPropagation()}
          />
        </div>
        <Btn primary onClick={onStart} className="w-full text-lg sm:text-xl py-4">
          ▶ RIDE {!isTouch && <span className="key ml-2">SPACE</span>}
        </Btn>
        <div className="flex gap-3 w-full">
          <Btn onClick={onGarage} color="#ff2bd6" className="flex-1">
            Garage
          </Btn>
          <Btn onClick={onScores} color="#ffe14d" className="flex-1">
            Scores
          </Btn>
        </div>
        <ControlsHint />
        <div className="panel px-4 py-3 w-full hidden [@media(min-height:640px)]:block">
          <div className="font-display text-[10px] tracking-[0.35em] text-white/45 mb-2 text-center">READING THE ROAD</div>
          <TrackLegend />
        </div>
      </div>
    </div>
  );
}

const LEGEND = [
  { c: '#22f3ff', label: 'ARROW', text: 'safe lane — follow it' },
  { c: '#ff2bd6', label: 'CHEVRONS', text: 'boost pad — free surge' },
  { c: '#ffe14d', label: 'RAMP', text: 'launch — huge air' },
  { c: '#ff2050', label: 'STRIPES', text: 'road ends — jump it' },
];

export function TrackLegend() {
  return (
    <div className="grid grid-cols-2 gap-x-4 gap-y-1.5 w-full">
      {LEGEND.map((l) => (
        <div key={l.label} className="flex items-center gap-2 text-[11px] leading-tight">
          <svg width="16" height="16" viewBox="0 0 16 16" className="shrink-0">
            <path d="M8 1 L15 14 H1 Z" fill={l.c} opacity="0.9" />
          </svg>
          <span className="font-display font-bold tracking-widest" style={{ color: l.c }}>
            {l.label}
          </span>
          <span className="text-white/55">{l.text}</span>
        </div>
      ))}
    </div>
  );
}

export function ControlsHint() {
  if (isTouch)
    return (
      <div className="text-center text-cyan-100/80 text-sm font-semibold tracking-wide leading-relaxed">
        SWIPE ◀ ▶ switch lanes · SWIPE ▲ or TAP jump · SWIPE ▼ slide / slam
      </div>
    );
  return (
    <div className="text-center text-cyan-100/80 text-sm font-semibold tracking-wide flex flex-wrap justify-center gap-x-4 gap-y-1">
      <span>
        <span className="key">←</span> <span className="key">→</span> / <span className="key">A</span> <span className="key">D</span> lanes
      </span>
      <span>
        <span className="key">↑</span> <span className="key">SPACE</span> jump
      </span>
      <span>
        <span className="key">↓</span> <span className="key">S</span> slide
      </span>
      <span>
        <span className="key">P</span> pause
      </span>
    </div>
  );
}

// ---------------- Garage ----------------
function StatBar({ label, value, color }: { label: string; value: number; color: string }) {
  return (
    <div className="flex items-center gap-3 text-xs font-display tracking-widest">
      <span className="w-20 text-white/70">{label}</span>
      <div className="flex-1 h-2 bg-white/10 overflow-hidden">
        <div className="h-full transition-all duration-500" style={{ width: `${Math.min(100, value * 100)}%`, background: color, boxShadow: `0 0 10px ${color}` }} />
      </div>
    </div>
  );
}

export function GarageScreen({
  save,
  index,
  setIndex,
  onAction,
  onBack,
}: {
  save: SaveData;
  index: number;
  setIndex: (i: number) => void;
  onAction: () => void;
  onBack: () => void;
}) {
  const bike = BIKES[index];
  const owned = save.unlocked.includes(bike.id);
  const selected = save.selected === bike.id;
  const canBuy = save.bank >= bike.price;
  const prev = () => setIndex((index + BIKES.length - 1) % BIKES.length);
  const next = () => setIndex((index + 1) % BIKES.length);
  return (
    <div className="absolute inset-0 flex flex-col justify-between p-4 sm:p-8 pointer-events-none">
      <div className="flex justify-between items-center pointer-events-auto">
        <Btn onClick={onBack} color="#ffffff" className="px-4 py-2 text-xs">
          ◀ Back
        </Btn>
        <div className="font-display text-xl sm:text-3xl font-black tracking-[0.3em] text-pink-300 neon-text">GARAGE</div>
        <Bank amount={save.bank} />
      </div>

      <div className="flex justify-between items-center pointer-events-auto">
        <button onClick={prev} className="btn-neon w-12 h-16 text-2xl" style={{ ['--c' as string]: bike.css }}>
          ‹
        </button>
        <button onClick={next} className="btn-neon w-12 h-16 text-2xl" style={{ ['--c' as string]: bike.css }}>
          ›
        </button>
      </div>

      <div key={bike.id} className="panel p-5 w-full max-w-md mx-auto pointer-events-auto fade-in">
        <div className="flex items-baseline justify-between">
          <div className="font-display text-2xl sm:text-3xl font-black neon-text" style={{ color: bike.css }}>
            {bike.name}
          </div>
          <div className="text-xs text-white/50 font-display">
            {index + 1}/{BIKES.length}
          </div>
        </div>
        <div className="text-white/70 text-sm mb-3">{bike.tagline}</div>
        <div className="space-y-2 mb-3">
          <StatBar label="HANDLING" value={(bike.handling - 0.6) / 0.8} color={bike.css} />
          <StatBar label="JUMP" value={(bike.jump - 0.8) / 0.35} color={bike.css} />
          <StatBar label="POWER" value={(bike.magnet - 0.6) / 1.0} color={bike.css} />
          <StatBar label="COINS" value={bike.coinMult / 2} color={bike.css} />
        </div>
        <div className="text-sm font-semibold mb-4" style={{ color: bike.css }}>
          ★ {bike.perk}
        </div>
        {owned ? (
          <Btn onClick={onAction} color={bike.css} primary={!selected} disabled={selected} className="w-full">
            {selected ? '✓ Equipped' : 'Equip'}
          </Btn>
        ) : (
          <Btn onClick={onAction} color={canBuy ? '#ffd23f' : '#777'} disabled={!canBuy} primary={canBuy} className="w-full">
            <span className="inline-flex items-center gap-2">
              🔒 Unlock · <CoinIcon /> {bike.price.toLocaleString()}
            </span>
          </Btn>
        )}
        {!owned && !canBuy && (
          <div className="text-center text-xs text-white/50 mt-2">Need {(bike.price - save.bank).toLocaleString()} more energy coins</div>
        )}
      </div>
    </div>
  );
}

// ---------------- Scores ----------------
export function ScoreTable({ scores, highlight = -1, limit = 10 }: { scores: ScoreEntry[]; highlight?: number; limit?: number }) {
  if (!scores.length) return <div className="text-center text-white/50 py-6 font-display text-sm tracking-widest">NO RUNS YET — GO RIDE!</div>;
  return (
    <table className="w-full text-sm">
      <thead>
        <tr className="text-[10px] font-display tracking-widest text-cyan-200/60">
          <th className="text-left py-1 w-8">#</th>
          <th className="text-left">PILOT</th>
          <th className="text-right hidden sm:table-cell">BIKE</th>
          <th className="text-right">DIST</th>
          <th className="text-right">SCORE</th>
        </tr>
      </thead>
      <tbody>
        {scores.slice(0, limit).map((s, i) => (
          <tr
            key={s.date + '-' + i}
            className={`border-t border-white/10 ${i === highlight ? 'bg-pink-500/25 text-white' : i === 0 ? 'text-[#ffe14d]' : 'text-white/85'}`}
          >
            <td className="py-1.5 font-display font-bold">{i + 1}</td>
            <td className="font-semibold tracking-wider">{s.name}</td>
            <td className="text-right text-white/60 hidden sm:table-cell text-xs">{s.bike}</td>
            <td className="text-right text-white/70">{s.distance.toLocaleString()}m</td>
            <td className="text-right font-display font-bold">{s.score.toLocaleString()}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

export function ScoresScreen({ save, onBack }: { save: SaveData; onBack: () => void }) {
  return (
    <div className="absolute inset-0 flex items-center justify-center p-4 bg-black/40">
      <div className="panel p-5 sm:p-7 w-full max-w-lg fade-in">
        <div className="font-display text-2xl sm:text-3xl font-black tracking-[0.25em] text-[#ffe14d] neon-text text-center mb-4">HIGH SCORES</div>
        <ScoreTable scores={save.scores} />
        <div className="text-center text-xs text-white/50 mt-3">Total runs: {save.runs}</div>
        <div className="mt-5 flex justify-center">
          <Btn onClick={onBack} color="#ffe14d">
            Back
          </Btn>
        </div>
      </div>
    </div>
  );
}

// ---------------- HUD ----------------
export interface HudRefs {
  score: RefObject<HTMLDivElement | null>;
  coins: RefObject<HTMLSpanElement | null>;
  dist: RefObject<HTMLSpanElement | null>;
  speed: RefObject<HTMLDivElement | null>;
  combo: RefObject<HTMLDivElement | null>;
  mult: RefObject<HTMLDivElement | null>;
  powers: Record<PowerKind, RefObject<HTMLDivElement | null>>;
}

export function HudView({ refs, visible, onPause, showHint }: { refs: HudRefs; visible: boolean; onPause: () => void; showHint: boolean }) {
  return (
    <div className="absolute inset-0 pointer-events-none transition-opacity duration-300" style={{ opacity: visible ? 1 : 0 }}>
      <div className="scrim-top absolute top-0 inset-x-0 h-40" />
      <div className="scrim-bottom absolute bottom-0 inset-x-0 h-32" />
      <div className="absolute top-0 inset-x-0 p-3 sm:p-5 flex justify-between items-start" style={{ paddingTop: 'max(12px, env(safe-area-inset-top))' }}>
        <div className="flex flex-col gap-1">
          <div className="flex items-center gap-2 font-display text-xl sm:text-2xl font-bold text-[#ffd23f] hud-num origin-left">
            <CoinIcon size={22} />
            <span ref={refs.coins}>0</span>
          </div>
          <div className="font-display text-xs sm:text-sm text-cyan-100 tracking-widest hud-num">
            <span ref={refs.dist}>0m</span>
          </div>
        </div>
        <div className="flex flex-col items-center absolute left-1/2 -translate-x-1/2 top-3 sm:top-5">
          <div ref={refs.score} className="font-display text-3xl sm:text-5xl font-black hud-num" style={{ color: '#e8fdff' }}>
            0
          </div>
          <div ref={refs.combo} className="combo-text font-display text-sm sm:text-base font-bold text-pink-300 hud-num h-6" />
          <div className="flex gap-2 mt-1">
            {(Object.keys(POWERS) as PowerKind[]).map((k) => (
              <div
                key={k}
                ref={refs.powers[k]}
                className="power-chip items-center gap-1 px-2 py-1 bg-black/50 border text-[11px] font-display font-bold tracking-wider"
                style={{ color: POWERS[k].css, borderColor: POWERS[k].css }}
              >
                <span>{POWERS[k].icon}</span>
                <span className="hidden sm:inline">{POWERS[k].label}</span>
                <div className="bar" />
              </div>
            ))}
          </div>
        </div>
        <div className="flex items-center gap-2">
          <div ref={refs.mult} className="font-display text-xl font-black text-[#ffe14d] neon-text" />
          <button
            onClick={onPause}
            className="pointer-events-auto w-11 h-11 grid place-items-center border border-cyan-300/50 bg-black/40 text-lg font-bold hover:bg-cyan-400/20"
            aria-label="Pause"
          >
            ❚❚
          </button>
        </div>
      </div>
      <div className="absolute bottom-0 inset-x-0 p-3 sm:p-5 flex flex-col items-center" style={{ paddingBottom: 'max(12px, env(safe-area-inset-bottom))' }}>
        {showHint && (
          <div className="mb-4 fade-in panel px-4 py-2">
            <ControlsHint />
          </div>
        )}
        <div className="w-full max-w-xs flex items-center gap-2">
          <span className="font-display text-[10px] tracking-widest text-cyan-200/70">SPEED</span>
          <div className="flex-1 h-1.5 bg-white/10 overflow-hidden">
            <div ref={refs.speed} className="speed-bar h-full" style={{ width: '5%' }} />
          </div>
        </div>
      </div>
    </div>
  );
}

// ---------------- Pause ----------------
export function PauseScreen({
  onResume,
  onRestart,
  onMenu,
  muted,
  onMute,
  time,
  onTime,
}: {
  onResume: () => void;
  onRestart: () => void;
  onMenu: () => void;
  muted: boolean;
  onMute: () => void;
  time: TimePref;
  onTime: (t: TimePref) => void;
}) {
  return (
    <div className="absolute inset-0 flex items-center justify-center bg-[#05010d]/60 backdrop-blur-sm p-4">
      <div className="panel p-6 sm:p-8 w-full max-w-xs flex flex-col gap-3 slam-in">
        <div className="font-display text-4xl font-black text-center tracking-[0.3em] text-cyan-300 neon-text mb-2">PAUSED</div>
        <Btn primary onClick={onResume}>
          ▶ Resume {!isTouch && <span className="key ml-1">P</span>}
        </Btn>
        <Btn onClick={onRestart} color="#ff2bd6">
          ↻ Restart {!isTouch && <span className="key ml-1">R</span>}
        </Btn>
        <Btn onClick={onMenu} color="#ffffff">
          Main Menu
        </Btn>
        <div className="flex justify-center gap-2 mt-1">
          <TimeToggle value={time} onChange={onTime} />
          <MuteBtn muted={muted} onToggle={onMute} />
        </div>
      </div>
    </div>
  );
}

// ---------------- Game Over ----------------
export interface RunResult {
  stats: RunStats;
  rank: number;
  earned: number;
  best: boolean;
}

export function GameOverScreen({
  result,
  save,
  onRestart,
  onGarage,
  onMenu,
}: {
  result: RunResult;
  save: SaveData;
  onRestart: () => void;
  onGarage: () => void;
  onMenu: () => void;
}) {
  const { stats, rank, earned, best } = result;
  const [shown, setShown] = useState(0);
  useEffect(() => {
    let raf = 0;
    const t0 = performance.now();
    const tick = () => {
      const t = Math.min(1, (performance.now() - t0) / 700);
      setShown(Math.floor(stats.score * (1 - Math.pow(1 - t, 3))));
      if (t < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [stats.score]);

  const nextBike: BikeDef | undefined = BIKES.find((b) => !save.unlocked.includes(b.id));
  const affordable = BIKES.filter((b) => !save.unlocked.includes(b.id) && b.price <= save.bank);

  return (
    <div className="absolute inset-0 flex items-center justify-center bg-[#05010d]/55 p-3 overflow-y-auto">
      <div className="panel p-5 sm:p-7 w-full max-w-lg my-auto">
        <div className="text-center slam-in">
          <div className="font-display text-4xl sm:text-5xl font-black tracking-[0.2em] text-[#ff2050] neon-text">WRECKED</div>
          {best && <div className="mt-1 font-display text-sm sm:text-base font-bold text-[#ffe14d] neon-text animate-pulse">★ NEW HIGH SCORE ★</div>}
          <div className="font-display text-5xl sm:text-6xl font-black text-white mt-2 neon-text" style={{ color: '#e8fdff' }}>
            {shown.toLocaleString()}
          </div>
        </div>
        <div className="grid grid-cols-4 gap-2 my-4 fade-in" style={{ animationDelay: '0.2s' }}>
          {[
            ['DIST', `${stats.distance}m`],
            ['COINS', `+${earned}`],
            ['NEAR', String(stats.nearMisses)],
            ['COMBO', `x${stats.maxCombo}`],
          ].map(([l, v]) => (
            <div key={l} className="bg-white/5 border border-white/10 py-2 text-center">
              <div className="text-[10px] font-display tracking-widest text-cyan-200/70">{l}</div>
              <div className={`font-display font-bold text-base sm:text-lg ${l === 'COINS' ? 'text-[#ffd23f]' : ''}`}>{v}</div>
            </div>
          ))}
        </div>
        {affordable.length > 0 ? (
          <div className="text-center text-sm font-bold text-[#5dff6a] mb-3 animate-pulse">🔓 {affordable[0].name} can be unlocked in the Garage!</div>
        ) : nextBike ? (
          <div className="mb-3">
            <div className="flex justify-between text-[11px] font-display tracking-widest text-white/60 mb-1">
              <span>NEXT: {nextBike.name}</span>
              <span>
                {save.bank}/{nextBike.price}
              </span>
            </div>
            <div className="h-1.5 bg-white/10">
              <div className="h-full" style={{ width: `${Math.min(100, (save.bank / nextBike.price) * 100)}%`, background: nextBike.css, boxShadow: `0 0 8px ${nextBike.css}` }} />
            </div>
          </div>
        ) : null}
        <div className="fade-in" style={{ animationDelay: '0.3s' }}>
          <ScoreTable scores={save.scores} highlight={rank} limit={5} />
        </div>
        <div className="flex flex-col gap-2 mt-5">
          <Btn primary onClick={onRestart} className="py-4 text-lg">
            ↻ Ride Again {!isTouch && <span className="key ml-2">SPACE</span>}
          </Btn>
          <div className="flex gap-2">
            <Btn onClick={onGarage} color="#ff2bd6" className="flex-1">
              Garage
            </Btn>
            <Btn onClick={onMenu} color="#ffffff" className="flex-1">
              Menu
            </Btn>
          </div>
        </div>
      </div>
    </div>
  );
}
