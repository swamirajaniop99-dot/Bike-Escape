import { useCallback, useEffect, useRef, useState } from 'react';
import { Engine, type RunStats } from './game/Engine';
import { BIKES, getBike, type TimePref } from './game/config';
import { insertScore, loadSave, writeSave, type SaveData } from './game/storage';
import { sfx } from './game/audio';
import {
  GameOverScreen,
  GarageScreen,
  HudView,
  PauseScreen,
  ScoresScreen,
  TitleScreen,
  type HudRefs,
  type RunResult,
} from './components/Screens';

type Screen = 'title' | 'garage' | 'scores' | 'playing' | 'paused' | 'dying' | 'over';

export default function App() {
  const mountRef = useRef<HTMLDivElement>(null);
  const engineRef = useRef<Engine | null>(null);
  const [screen, setScreen] = useState<Screen>('title');
  const [save, setSave] = useState<SaveData>(() => loadSave());
  const saveRef = useRef(save);
  saveRef.current = save;
  const [result, setResult] = useState<RunResult | null>(null);
  const [garageIdx, setGarageIdx] = useState(() => Math.max(0, BIKES.findIndex((b) => b.id === save.selected)));
  const [showHint, setShowHint] = useState(false);
  const overAt = useRef(0);
  const hintTimer = useRef<number | null>(null);

  const popupsRef = useRef<HTMLDivElement>(null);
  const flashRef = useRef<HTMLDivElement>(null);
  const vignetteRef = useRef<HTMLDivElement>(null);
  const hudRefs: HudRefs = {
    score: useRef<HTMLDivElement>(null),
    coins: useRef<HTMLSpanElement>(null),
    dist: useRef<HTMLSpanElement>(null),
    speed: useRef<HTMLDivElement>(null),
    combo: useRef<HTMLDivElement>(null),
    mult: useRef<HTMLDivElement>(null),
    powers: {
      magnet: useRef<HTMLDivElement>(null),
      shield: useRef<HTMLDivElement>(null),
      boost: useRef<HTMLDivElement>(null),
      multi: useRef<HTMLDivElement>(null),
    },
  };
  const hudRefsRef = useRef(hudRefs);

  const updateSave = useCallback((fn: (s: SaveData) => SaveData) => {
    const next = fn({ ...saveRef.current });
    saveRef.current = next;
    writeSave(next);
    setSave(next);
  }, []);

  const handleGameOver = useCallback((stats: RunStats) => {
    const s: SaveData = { ...saveRef.current, scores: [...saveRef.current.scores] };
    const bike = getBike(stats.bikeId);
    const earned = stats.coins * bike.coinMult;
    s.bank += earned;
    s.runs += 1;
    const prevBest = s.scores[0]?.score ?? 0;
    const rank =
      stats.score > 0
        ? insertScore(s, { name: s.name.trim() || 'RIDER', score: stats.score, distance: stats.distance, bike: bike.name, date: Date.now() })
        : -1;
    saveRef.current = s;
    writeSave(s);
    setSave(s);
    setResult({ stats, rank, earned, best: stats.score > prevBest && stats.score > 0 });
    overAt.current = performance.now();
    setScreen('over');
  }, []);
  const gameOverRef = useRef(handleGameOver);
  gameOverRef.current = handleGameOver;

  // Engine lifecycle
  useEffect(() => {
    const mount = mountRef.current!;
    const eng = new Engine(mount, {
      onState: (s) => {
        if (s === 'playing' || s === 'paused' || s === 'dying') setScreen(s);
      },
      onGameOver: (st) => gameOverRef.current(st),
    });
    const r = hudRefsRef.current;
    eng.setHud({
      score: r.score.current,
      coins: r.coins.current,
      dist: r.dist.current,
      speed: r.speed.current,
      combo: r.combo.current,
      mult: r.mult.current,
      popups: popupsRef.current,
      flash: flashRef.current,
      vignette: vignetteRef.current,
      powers: {
        magnet: r.powers.magnet.current,
        shield: r.powers.shield.current,
        boost: r.powers.boost.current,
        multi: r.powers.multi.current,
      },
    });
    eng.setBike(saveRef.current.selected);
    eng.setTimePref(saveRef.current.time);
    sfx.setMuted(saveRef.current.muted);
    engineRef.current = eng;
    return () => {
      eng.dispose();
      engineRef.current = null;
    };
  }, []);

  const startRun = useCallback(() => {
    const eng = engineRef.current;
    if (!eng) return;
    sfx.unlock();
    (document.activeElement as HTMLElement | null)?.blur?.();
    eng.setMenuView('title');
    eng.setBike(saveRef.current.selected);
    eng.start();
    setShowHint(saveRef.current.runs < 3);
    if (hintTimer.current) clearTimeout(hintTimer.current);
    hintTimer.current = window.setTimeout(() => setShowHint(false), 4000);
  }, []);

  const goMenu = useCallback(() => {
    sfx.click();
    engineRef.current?.setBike(saveRef.current.selected);
    engineRef.current?.setMenuView('title');
    engineRef.current?.toMenu();
    setScreen('title');
  }, []);

  const openGarage = useCallback(() => {
    sfx.unlock();
    sfx.click();
    const eng = engineRef.current;
    if (eng && eng.state !== 'menu') eng.toMenu();
    const idx = Math.max(0, BIKES.findIndex((b) => b.id === saveRef.current.selected));
    setGarageIdx(idx);
    eng?.setMenuView('garage');
    eng?.setBike(BIKES[idx].id);
    setScreen('garage');
  }, []);

  const setGarage = useCallback((i: number) => {
    sfx.click();
    setGarageIdx(i);
    engineRef.current?.setBike(BIKES[i].id);
  }, []);

  const garageAction = useCallback(() => {
    const bike = BIKES[garageIdx];
    const s = saveRef.current;
    if (s.unlocked.includes(bike.id)) {
      if (s.selected === bike.id) return;
      sfx.click();
      updateSave((d) => ({ ...d, selected: bike.id }));
    } else if (s.bank >= bike.price) {
      sfx.power();
      updateSave((d) => ({ ...d, bank: d.bank - bike.price, unlocked: [...d.unlocked, bike.id], selected: bike.id }));
    } else {
      sfx.bump();
    }
  }, [garageIdx, updateSave]);

  const setTime = useCallback(
    (t: TimePref) => {
      sfx.unlock();
      sfx.click();
      engineRef.current?.setTimePref(t);
      updateSave((d) => ({ ...d, time: t }));
    },
    [updateSave]
  );

  const toggleMute = useCallback(() => {
    sfx.unlock();
    updateSave((d) => {
      sfx.setMuted(!d.muted);
      return { ...d, muted: !d.muted };
    });
  }, [updateSave]);

  // Global keyboard for menus
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const k = e.code;
      const eng = engineRef.current;
      if (!eng) return;
      if (screen === 'title') {
        if (k === 'Space' || k === 'Enter') {
          e.preventDefault();
          startRun();
        } else if (k === 'KeyG') openGarage();
        else if (k === 'KeyH') {
          sfx.unlock();
          setScreen('scores');
        }
      } else if (screen === 'paused') {
        if (k === 'Escape' || k === 'KeyP' || k === 'Space' || k === 'Enter') {
          e.preventDefault();
          eng.resume();
        } else if (k === 'KeyR') startRun();
        else if (k === 'KeyM' || k === 'KeyQ') goMenu();
      } else if (screen === 'over') {
        if (performance.now() - overAt.current < 450) return;
        if (k === 'Space' || k === 'Enter' || k === 'KeyR') {
          e.preventDefault();
          startRun();
        } else if (k === 'Escape' || k === 'KeyM') goMenu();
        else if (k === 'KeyG') openGarage();
      } else if (screen === 'garage') {
        if (k === 'ArrowLeft' || k === 'KeyA') setGarage((garageIdx + BIKES.length - 1) % BIKES.length);
        else if (k === 'ArrowRight' || k === 'KeyD') setGarage((garageIdx + 1) % BIKES.length);
        else if (k === 'Enter' || k === 'Space') {
          e.preventDefault();
          garageAction();
        } else if (k === 'Escape' || k === 'Backspace') goMenu();
      } else if (screen === 'scores') {
        if (k === 'Escape' || k === 'Enter' || k === 'Space' || k === 'Backspace') {
          e.preventDefault();
          setScreen('title');
        }
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [screen, garageIdx, startRun, goMenu, openGarage, setGarage, garageAction]);

  const inRun = screen === 'playing' || screen === 'paused' || screen === 'dying';

  return (
    <div className="fixed inset-0 overflow-hidden bg-[#05010d] select-none">
      <div ref={mountRef} className="absolute inset-0" />
      {/* speed vignette */}
      <div
        ref={vignetteRef}
        className="absolute inset-0 pointer-events-none"
        style={{
          opacity: 0,
          background: 'radial-gradient(ellipse at center, transparent 45%, rgba(255,43,214,0.35) 85%, rgba(20,0,40,0.85) 110%)',
        }}
      />
      <div className="absolute inset-0 scanlines opacity-40" />
      <div ref={flashRef} className="absolute inset-0 pointer-events-none" style={{ opacity: 0 }} />
      <div ref={popupsRef} className="absolute inset-0 pointer-events-none overflow-hidden" />

      <HudView
        refs={hudRefs}
        visible={inRun}
        onPause={() => {
          (document.activeElement as HTMLElement | null)?.blur?.();
          engineRef.current?.pause();
        }}
        showHint={showHint && screen === 'playing'}
      />

      {screen === 'title' && (
        <TitleScreen
          save={save}
          onStart={startRun}
          onGarage={openGarage}
          onScores={() => {
            sfx.unlock();
            sfx.click();
            setScreen('scores');
          }}
          onName={(n) => updateSave((d) => ({ ...d, name: n }))}
          onMute={toggleMute}
          onTime={setTime}
        />
      )}
      {screen === 'garage' && <GarageScreen save={save} index={garageIdx} setIndex={setGarage} onAction={garageAction} onBack={goMenu} />}
      {screen === 'scores' && (
        <ScoresScreen
          save={save}
          onBack={() => {
            sfx.click();
            setScreen('title');
          }}
        />
      )}
      {screen === 'paused' && (
        <PauseScreen
          onResume={() => {
            (document.activeElement as HTMLElement | null)?.blur?.();
            engineRef.current?.resume();
          }}
         onRestart={startRun} onMenu={goMenu} muted={save.muted} onMute={toggleMute} time={save.time} onTime={setTime} />
      )}
      {screen === 'over' && result && <GameOverScreen result={result} save={save} onRestart={startRun} onGarage={openGarage} onMenu={goMenu} />}
    </div>
  );
}
