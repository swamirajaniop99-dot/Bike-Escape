import * as THREE from 'three';

function canvas(w: number, h: number) {
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  return { c, g: c.getContext('2d')! };
}

function tex(c: HTMLCanvasElement, srgb = true, aniso = 4) {
  const t = new THREE.CanvasTexture(c);
  if (srgb) t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = aniso;
  return t;
}

function seeded(seed: number) {
  let r = seed * 9301 + 49297;
  return () => {
    r = (r * 9301 + 49297) % 233280;
    return r / 233280;
  };
}

function speckle(g: CanvasRenderingContext2D, w: number, h: number, rnd: () => number, n: number, colors: string[], size = 2) {
  for (let i = 0; i < n; i++) {
    g.fillStyle = colors[Math.floor(rnd() * colors.length)];
    g.globalAlpha = 0.15 + rnd() * 0.5;
    g.fillRect(rnd() * w, rnd() * h, size, size);
  }
  g.globalAlpha = 1;
}

/* ---------------- facades (day) + windows (night emissive) ---------------- */

const FACADE_BASE = [
  { wall: '#b9b3a6', win: '#4d6d86', frame: '#8d887c' },
  { wall: '#9fa8b2', win: '#38566e', frame: '#79828c' },
  { wall: '#c9b7a0', win: '#5d7286', frame: '#9c8c78' },
  { wall: '#8e9aa6', win: '#2f4a63', frame: '#6d7883' },
];

export function makeFacadeTexture(seed: number) {
  const { c, g } = canvas(128, 256);
  const p = FACADE_BASE[seed % FACADE_BASE.length];
  const rnd = seeded(seed + 3);
  g.fillStyle = p.wall;
  g.fillRect(0, 0, 128, 256);
  speckle(g, 128, 256, rnd, 900, ['#000000', '#ffffff', p.frame], 2);
  // floor slabs
  g.fillStyle = p.frame;
  for (let y = 0; y < 256; y += 16) g.fillRect(0, y, 128, 2);
  // windows
  for (let y = 4; y < 256; y += 16) {
    for (let x = 5; x < 128; x += 13) {
      g.fillStyle = p.win;
      g.fillRect(x, y, 9, 10);
      g.fillStyle = 'rgba(255,255,255,0.16)';
      g.fillRect(x, y, 9, 3);
      g.fillStyle = p.frame;
      g.fillRect(x + 4, y, 1, 10);
    }
  }
  // ground floor / entrance band
  g.fillStyle = 'rgba(0,0,0,0.25)';
  g.fillRect(0, 236, 128, 20);
  const t = tex(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  return t;
}

export function makeWindowTexture(seed: number) {
  const { c, g } = canvas(128, 256);
  const rnd = seeded(seed * 7 + 11);
  g.fillStyle = '#000000';
  g.fillRect(0, 0, 128, 256);
  const warm = ['#ffd9a0', '#ffe9c4', '#ffc978', '#fff4dd'];
  const cool = ['#bfe6ff', '#8fd0ff', '#dff3ff'];
  for (let y = 4; y < 256; y += 16) {
    for (let x = 5; x < 128; x += 13) {
      const v = rnd();
      if (v < 0.46) {
        g.fillStyle = v < 0.32 ? warm[Math.floor(rnd() * warm.length)] : cool[Math.floor(rnd() * cool.length)];
        g.globalAlpha = 0.5 + rnd() * 0.5;
        g.fillRect(x, y, 9, 10);
      }
    }
  }
  g.globalAlpha = 1;
  const t = tex(c, false);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  return t;
}

/* ---------------- asphalt road ---------------- */

export function makeAsphaltMap() {
  const { c, g } = canvas(256, 256);
  const rnd = seeded(21);
  g.fillStyle = '#4a4d52';
  g.fillRect(0, 0, 256, 256);
  speckle(g, 256, 256, rnd, 5200, ['#3a3d42', '#5b5f65', '#2f3236', '#6a6e74'], 2);
  // tyre polish tracks
  g.globalAlpha = 0.14;
  g.fillStyle = '#22252a';
  g.fillRect(58, 0, 22, 256);
  g.fillRect(176, 0, 22, 256);
  g.globalAlpha = 1;
  // cracks + patches
  for (let i = 0; i < 7; i++) {
    g.strokeStyle = 'rgba(30,32,36,0.5)';
    g.lineWidth = 1 + rnd();
    g.beginPath();
    let x = rnd() * 256;
    let y = rnd() * 256;
    g.moveTo(x, y);
    for (let k = 0; k < 5; k++) {
      x += (rnd() - 0.5) * 40;
      y += rnd() * 40;
      g.lineTo(x, y);
    }
    g.stroke();
  }
  // solid white edge lines
  g.fillStyle = '#e8e8e2';
  g.fillRect(7, 0, 5, 256);
  g.fillRect(244, 0, 5, 256);
  g.globalAlpha = 0.25;
  g.fillStyle = '#000';
  g.fillRect(7, 0, 5, 256);
  g.fillRect(244, 0, 5, 256);
  g.globalAlpha = 1;
  g.fillStyle = '#f2f2ec';
  g.fillRect(8, 0, 3, 256);
  g.fillRect(245, 0, 3, 256);
  // dashed lane dividers
  for (const u of [0.357, 0.643]) {
    const x = u * 256;
    g.fillStyle = '#f4f4ee';
    g.fillRect(x - 3, 26, 6, 128);
    g.fillStyle = 'rgba(0,0,0,0.18)';
    g.fillRect(x - 3, 150, 6, 6);
  }
  return tex(c, true, 8);
}

export function makeAsphaltEmissive() {
  const { c, g } = canvas(256, 256);
  g.fillStyle = '#000000';
  g.fillRect(0, 0, 256, 256);
  g.fillStyle = '#00e5ff';
  g.fillRect(6, 0, 7, 256);
  g.fillRect(243, 0, 7, 256);
  g.fillStyle = '#ff2bd6';
  for (const u of [0.357, 0.643]) {
    const x = u * 256;
    g.fillRect(x - 1.5, 26, 3, 128);
  }
  // cat's eyes
  g.fillStyle = '#fff3b0';
  for (const u of [0.357, 0.643]) for (let y = 20; y < 256; y += 44) g.fillRect(u * 256 - 2, y, 4, 7);
  return tex(c, false, 4);
}

/* ---------------- ground / verge ---------------- */

export function makeGroundMap() {
  const { c, g } = canvas(128, 128);
  const rnd = seeded(5);
  g.fillStyle = '#5d6b46';
  g.fillRect(0, 0, 128, 128);
  speckle(g, 128, 128, rnd, 3000, ['#4c5a3a', '#6f7d52', '#7b6a4a', '#3f4a30', '#8a9163'], 2);
  g.globalAlpha = 0.18;
  g.fillStyle = '#6b5a42';
  for (let i = 0; i < 14; i++) g.fillRect(rnd() * 128, rnd() * 128, 6 + rnd() * 18, 4 + rnd() * 10);
  g.globalAlpha = 1;
  const t = tex(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  return t;
}

export function makeGroundEmissive() {
  const { c, g } = canvas(64, 64);
  g.fillStyle = '#000000';
  g.fillRect(0, 0, 64, 64);
  g.strokeStyle = '#ff2bd6';
  g.lineWidth = 2;
  g.strokeRect(0, 0, 64, 64);
  const t = tex(c, false);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  return t;
}

/* ---------------- props ---------------- */

export function makeCloudTexture() {
  const { c, g } = canvas(256, 128);
  const rnd = seeded(9);
  g.clearRect(0, 0, 256, 128);
  for (let i = 0; i < 26; i++) {
    const x = 40 + rnd() * 176;
    const y = 40 + rnd() * 56;
    const r = 16 + rnd() * 34;
    const grd = g.createRadialGradient(x, y, 0, x, y, r);
    grd.addColorStop(0, 'rgba(255,255,255,0.85)');
    grd.addColorStop(0.5, 'rgba(255,255,255,0.35)');
    grd.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = grd;
    g.beginPath();
    g.arc(x, y, r, 0, Math.PI * 2);
    g.fill();
  }
  return tex(c);
}

export function makeSignTexture(variant: number) {
  const { c, g } = canvas(256, 96);
  const rnd = seeded(variant * 13 + 2);
  g.fillStyle = variant % 2 ? '#0b6b3a' : '#123a6b';
  g.fillRect(0, 0, 256, 96);
  g.strokeStyle = '#f2f2f2';
  g.lineWidth = 5;
  g.strokeRect(6, 6, 244, 84);
  g.fillStyle = '#ffffff';
  g.font = 'bold 26px Arial, sans-serif';
  const words = [
    ['NEO-TOKYO', 'EXIT 7 · 2 KM'],
    ['HARBOUR', 'GRID 12 · 800 M'],
    ['AIRPORT', 'SECTOR 4 · 15 KM'],
    ['DOWNTOWN', 'EXIT 3 · 1 KM'],
  ];
  const w = words[variant % words.length];
  g.textAlign = 'center';
  g.fillText(w[0], 128, 42);
  g.font = 'bold 17px Arial, sans-serif';
  g.globalAlpha = 0.9;
  g.fillText(w[1], 128, 70);
  g.globalAlpha = 1;
  // arrow
  g.beginPath();
  const ax = 24 + rnd() * 8;
  g.moveTo(ax, 48);
  g.lineTo(ax + 16, 36);
  g.lineTo(ax + 16, 44);
  g.lineTo(ax + 30, 44);
  g.lineTo(ax + 30, 52);
  g.lineTo(ax + 16, 52);
  g.lineTo(ax + 16, 60);
  g.closePath();
  g.fill();
  return tex(c);
}

export function makeBillboardTexture(variant: number) {
  const { c, g } = canvas(256, 128);
  const bg = ['#ff2bd6', '#22f3ff', '#ffb02e', '#7a5cff'][variant % 4];
  g.fillStyle = '#0a0714';
  g.fillRect(0, 0, 256, 128);
  g.fillStyle = bg;
  g.fillRect(0, 0, 256, 10);
  g.fillRect(0, 118, 256, 10);
  g.font = 'bold 40px Arial, sans-serif';
  g.textAlign = 'center';
  g.fillStyle = bg;
  const ads = ['RIDE OR DIE', 'VOLT COLA', 'SKYNET 5G', 'TURBO FUEL'];
  g.fillText(ads[variant % ads.length], 128, 62);
  g.font = 'bold 18px Arial, sans-serif';
  g.fillStyle = '#ffffff';
  g.fillText('★ 24 / 7 ★ NEON CITY ★', 128, 92);
  return tex(c);
}

/* ---------------- fx helpers ---------------- */

export function makeGlowTexture() {
  const { c, g } = canvas(64, 64);
  const grd = g.createRadialGradient(32, 32, 0, 32, 32, 32);
  grd.addColorStop(0, 'rgba(255,255,255,1)');
  grd.addColorStop(0.25, 'rgba(255,255,255,0.6)');
  grd.addColorStop(1, 'rgba(255,255,255,0)');
  g.fillStyle = grd;
  g.fillRect(0, 0, 64, 64);
  return new THREE.CanvasTexture(c);
}

export function makeHazardTexture() {
  const { c, g } = canvas(128, 16);
  g.fillStyle = '#e8e8e2';
  g.fillRect(0, 0, 128, 16);
  g.fillStyle = '#d8202a';
  for (let x = -16; x < 140; x += 16) {
    g.beginPath();
    g.moveTo(x, 16);
    g.lineTo(x + 8, 16);
    g.lineTo(x + 16, 0);
    g.lineTo(x + 8, 0);
    g.closePath();
    g.fill();
  }
  const t = tex(c);
  t.wrapS = THREE.RepeatWrapping;
  t.repeat.x = 4;
  return t;
}
