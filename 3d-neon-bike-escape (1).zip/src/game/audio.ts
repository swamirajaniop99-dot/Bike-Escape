// Tiny procedural synth: all sounds generated at runtime, no assets.
export class Sfx {
  ctx: AudioContext | null = null;
  master: GainNode | null = null;
  sfxGain: GainNode | null = null;
  musicGain: GainNode | null = null;
  noiseBuf: AudioBuffer | null = null;
  muted = false;
  musicOn = false;
  private nextNote = 0;
  private step = 0;
  private timer: number | null = null;
  intensity = 0;

  unlock() {
    if (!this.ctx) {
      const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AC) return;
      this.ctx = new AC();
      this.master = this.ctx.createGain();
      this.master.gain.value = this.muted ? 0 : 0.7;
      const comp = this.ctx.createDynamicsCompressor();
      comp.threshold.value = -14;
      comp.ratio.value = 4;
      this.master.connect(comp).connect(this.ctx.destination);
      this.sfxGain = this.ctx.createGain();
      this.sfxGain.gain.value = 0.8;
      this.sfxGain.connect(this.master);
      this.musicGain = this.ctx.createGain();
      this.musicGain.gain.value = 0.32;
      this.musicGain.connect(this.master);
      const len = this.ctx.sampleRate * 1;
      this.noiseBuf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
      const data = this.noiseBuf.getChannelData(0);
      for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;
    }
    if (this.ctx.state === 'suspended') this.ctx.resume();
  }

  setMuted(m: boolean) {
    this.muted = m;
    if (this.master && this.ctx) this.master.gain.setTargetAtTime(m ? 0 : 0.7, this.ctx.currentTime, 0.02);
  }

  private tone(freq: number, dur: number, type: OscillatorType, vol: number, slideTo?: number, delay = 0, dest?: AudioNode) {
    if (!this.ctx || !this.sfxGain) return;
    const t = this.ctx.currentTime + delay;
    const o = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    o.type = type;
    o.frequency.setValueAtTime(freq, t);
    if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, t + dur);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(vol, t + 0.008);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g).connect(dest ?? this.sfxGain);
    o.start(t);
    o.stop(t + dur + 0.02);
  }

  private noise(dur: number, vol: number, filterFreq: number, type: BiquadFilterType = 'lowpass', delay = 0, sweepTo?: number, dest?: AudioNode) {
    if (!this.ctx || !this.sfxGain || !this.noiseBuf) return;
    const t = this.ctx.currentTime + delay;
    const s = this.ctx.createBufferSource();
    s.buffer = this.noiseBuf;
    const f = this.ctx.createBiquadFilter();
    f.type = type;
    f.frequency.setValueAtTime(filterFreq, t);
    if (sweepTo) f.frequency.exponentialRampToValueAtTime(sweepTo, t + dur);
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    s.connect(f).connect(g).connect(dest ?? this.sfxGain);
    s.start(t, Math.random() * 0.5);
    s.stop(t + dur + 0.02);
  }

  coin(chain: number) {
    const base = 880 * Math.pow(1.0595, Math.min(chain, 14));
    this.tone(base, 0.09, 'square', 0.08);
    this.tone(base * 1.5, 0.14, 'sine', 0.1, undefined, 0.04);
  }
  lane() {
    this.noise(0.08, 0.12, 2500, 'bandpass', 0, 6000);
  }
  bump() {
    this.tone(140, 0.15, 'square', 0.15, 60);
    this.noise(0.12, 0.2, 800);
  }
  jump() {
    this.tone(220, 0.22, 'sawtooth', 0.08, 660);
    this.noise(0.18, 0.1, 1200, 'bandpass', 0, 4000);
  }
  land() {
    this.tone(120, 0.12, 'sine', 0.2, 50);
    this.noise(0.08, 0.12, 600);
  }
  duck() {
    this.noise(0.2, 0.15, 4000, 'bandpass', 0, 800);
  }
  pad() {
    this.tone(300, 0.3, 'sawtooth', 0.12, 1400);
    this.tone(600, 0.25, 'square', 0.06, 2400, 0.03);
    this.noise(0.3, 0.16, 900, 'bandpass', 0, 6000);
  }
  ramp() {
    this.tone(180, 0.35, 'sawtooth', 0.14, 900);
    this.tone(720, 0.3, 'triangle', 0.1, 1500, 0.06);
    this.noise(0.25, 0.18, 1500, 'bandpass', 0, 7000);
  }
  nearMiss(combo: number) {
    this.noise(0.25, 0.25, 600, 'bandpass', 0, 5000);
    this.tone(500 + combo * 60, 0.18, 'triangle', 0.12, 1200 + combo * 80, 0.05);
  }
  power() {
    [523, 659, 784, 1047].forEach((f, i) => this.tone(f, 0.18, 'square', 0.07, undefined, i * 0.06));
    this.tone(1568, 0.4, 'sine', 0.08, undefined, 0.24);
  }
  shieldBreak() {
    this.tone(900, 0.3, 'sawtooth', 0.1, 120);
    this.noise(0.4, 0.3, 3000, 'highpass');
  }
  smash() {
    this.noise(0.35, 0.35, 2000, 'lowpass', 0, 200);
    this.tone(200, 0.2, 'square', 0.1, 50);
  }
  crash() {
    this.noise(1.1, 0.6, 3000, 'lowpass', 0, 80);
    this.tone(180, 0.7, 'sawtooth', 0.2, 30);
    this.tone(90, 0.9, 'sine', 0.35, 25);
  }
  fall() {
    this.tone(700, 1.0, 'triangle', 0.15, 60);
  }
  click() {
    this.tone(1200, 0.05, 'square', 0.06);
  }
  go() {
    this.tone(440, 0.12, 'square', 0.08);
    this.tone(880, 0.3, 'square', 0.08, undefined, 0.12);
  }

  // ---------- Music: simple synthwave loop ----------
  startMusic() {
    if (!this.ctx || this.musicOn) return;
    this.musicOn = true;
    this.nextNote = this.ctx.currentTime + 0.05;
    this.step = 0;
    this.timer = window.setInterval(() => this.schedule(), 25);
  }
  stopMusic() {
    this.musicOn = false;
    if (this.timer !== null) clearInterval(this.timer);
    this.timer = null;
  }
  private schedule() {
    if (!this.ctx || !this.musicGain) return;
    const spb = 60 / 124 / 4; // 16th notes at 124bpm
    // A minor - F - C - G progression roots
    const roots = [45, 41, 48, 43];
    while (this.nextNote < this.ctx.currentTime + 0.12) {
      const s = this.step % 64;
      const bar = Math.floor(s / 16);
      const root = roots[bar];
      const t = this.nextNote - this.ctx.currentTime;
      const st = s % 16;
      // bass: driving 8ths with octave jumps
      if (st % 2 === 0) {
        const n = root + (st % 4 === 2 ? 12 : 0);
        this.tone(midi(n), spb * 1.8, 'sawtooth', 0.12, undefined, t, this.musicGain);
      }
      // kick
      if (st % 4 === 0) this.tone(150, 0.18, 'sine', 0.5, 40, t, this.musicGain);
      // snare
      if (st === 4 || st === 12) this.noise(0.15, 0.18, 1800, 'bandpass', t, undefined, this.musicGain);
      // hats
      if (st % 2 === 1) this.noise(0.04, 0.06 + this.intensity * 0.04, 8000, 'highpass', t, undefined, this.musicGain);
      // arp when intensity rises
      if (this.intensity > 0.25) {
        const arp = [0, 3, 7, 12, 7, 3, 12, 15];
        const n = root + 24 + arp[st % 8] + (bar === 2 || bar === 3 ? 0 : 0);
        this.tone(midi(n), spb * 0.9, 'square', 0.025 + this.intensity * 0.02, undefined, t, this.musicGain);
      }
      this.nextNote += spb;
      this.step++;
    }
  }
}

function midi(n: number) {
  return 440 * Math.pow(2, (n - 69) / 12);
}

export const sfx = new Sfx();
