import type { TimePref } from './config';

export interface ScoreEntry {
  name: string;
  score: number;
  distance: number;
  bike: string;
  date: number;
}

export interface SaveData {
  bank: number;
  unlocked: string[];
  selected: string;
  name: string;
  scores: ScoreEntry[];
  muted: boolean;
  runs: number;
  time: TimePref;
}

const KEY = 'neon-bike-escape-v2';

const DEFAULT: SaveData = {
  bank: 0,
  unlocked: ['volt'],
  selected: 'volt',
  name: 'RIDER',
  scores: [],
  muted: false,
  runs: 0,
  time: 'cycle',
};

export function loadSave(): SaveData {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return { ...DEFAULT, unlocked: [...DEFAULT.unlocked], scores: [] };
    const d = JSON.parse(raw);
    return {
      ...DEFAULT,
      ...d,
      unlocked: Array.isArray(d.unlocked) ? d.unlocked : ['volt'],
      scores: Array.isArray(d.scores) ? d.scores : [],
    };
  } catch {
    return { ...DEFAULT, unlocked: [...DEFAULT.unlocked], scores: [] };
  }
}

export function writeSave(d: SaveData) {
  try {
    localStorage.setItem(KEY, JSON.stringify(d));
  } catch {
    /* ignore */
  }
}

/** Inserts the score and returns its rank (0-based) or -1 if it didn't place. */
export function insertScore(d: SaveData, e: ScoreEntry): number {
  const list = [...d.scores, e].sort((a, b) => b.score - a.score).slice(0, 10);
  d.scores = list;
  return list.indexOf(e);
}
