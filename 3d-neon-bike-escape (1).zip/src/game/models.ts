import * as THREE from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import type { BikeDef, PowerKind } from './config';
import { POWERS, ROAD_HALF } from './config';

export type ObKind = 'barrier' | 'block' | 'laserLow' | 'laserHigh' | 'drone' | 'car' | 'gapEdge';
export type DecalKind = 'arrow' | 'pad' | 'ramp' | 'warn';
export type TileVariant = 'road' | 'roadLit' | 'roadTree' | 'tunnel' | 'bridge';

const lambert = (color: number, extra: THREE.MeshLambertMaterialParameters = {}) =>
  new THREE.MeshLambertMaterial({ color, ...extra });

/** Normalises to non-indexed and adds a flat vertex-colour attribute so
 *  mixed primitives (boxes, cylinders, icosahedra) can be merged safely. */
function paint(geo: THREE.BufferGeometry, color: number) {
  const src = geo.index ? geo.toNonIndexed() : geo;
  const c = new THREE.Color(color);
  const n = src.attributes.position.count;
  const arr = new Float32Array(n * 3);
  for (let i = 0; i < n; i++) {
    arr[i * 3] = c.r;
    arr[i * 3 + 1] = c.g;
    arr[i * 3 + 2] = c.b;
  }
  src.setAttribute('color', new THREE.BufferAttribute(arr, 3));
  return src;
}

function bx(w: number, h: number, d: number, x: number, y: number, z: number, color: number) {
  const g = new THREE.BoxGeometry(w, h, d);
  g.translate(x, y, z);
  return paint(g, color);
}

const CAR_PAINTS = [0xe8e9eb, 0x2b3138, 0xb41f24, 0x1f4c8f, 0xd9a520, 0x6f757c, 0x186a4b, 0xf2f2f2];
const pick = <T,>(arr: T[]) => arr[Math.floor(Math.random() * arr.length)];

export class Models {
  glowTex: THREE.Texture;
  hazardTex: THREE.Texture;
  signTex: THREE.Texture[];

  nightK = 0;
  /** Lambert materials whose emissiveMap lights up after dark. */
  private emissiveMats: THREE.MeshLambertMaterial[] = [];
  /** Additive/basic parts that only exist after dark. */
  private nightMats: THREE.Material[] = [];
  private nightMeshes: THREE.Object3D[] = [];

  // shared
  steel = lambert(0x9aa3ab);
  darkSteel = lambert(0x3b4148);
  concrete = lambert(0x8b867c);
  tyre = lambert(0x15161a);
  glass = lambert(0x1b2b38, { emissive: 0x0a141c });
  white = new THREE.MeshBasicMaterial({ color: 0xfff8e8 });
  red = new THREE.MeshBasicMaterial({ color: 0xff2a2a });
  boxGeo = new THREE.BoxGeometry(1, 1, 1);
  wheelGeo: THREE.CylinderGeometry;
  hubGeo: THREE.CylinderGeometry;

  // road / kerb
  kerbGeo: THREE.BufferGeometry;
  neonStripGeo: THREE.BufferGeometry;
  kerbMat = lambert(0xffffff, { vertexColors: true });
  neonStripMat: THREE.MeshBasicMaterial;
  lampGeo: THREE.BufferGeometry;
  lampGlowGeo: THREE.PlaneGeometry;
  treeGeos: THREE.BufferGeometry[] = [];
  vcMat = lambert(0xffffff, { vertexColors: true });

  hazardMat: THREE.MeshBasicMaterial;

  constructor(glowTex: THREE.Texture, hazardTex: THREE.Texture, signTex: THREE.Texture[]) {
    this.glowTex = glowTex;
    this.hazardTex = hazardTex;
    this.signTex = signTex;
    this.hazardMat = new THREE.MeshBasicMaterial({ map: hazardTex });

    this.neonStripMat = this.night(new THREE.MeshBasicMaterial({
      color: 0x35e6ff,
      transparent: true,
      opacity: 0,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    }));

    this.wheelGeo = new THREE.CylinderGeometry(0.36, 0.36, 0.26, 12);
    this.wheelGeo.rotateZ(Math.PI / 2);
    this.hubGeo = new THREE.CylinderGeometry(0.19, 0.19, 0.28, 8);
    this.hubGeo.rotateZ(Math.PI / 2);

    this.kerbGeo = this.buildKerbGeo();
    this.neonStripGeo = this.buildNeonStripGeo();
    this.lampGeo = this.buildLampGeo();
    this.lampGlowGeo = new THREE.PlaneGeometry(1.5, 1.1);
    for (let i = 0; i < 3; i++) this.treeGeos.push(this.buildTreeGeo(i));
  }

  /** Registers a material/mesh that should only be visible after dark. */
  private night<T extends THREE.Material>(m: T): T {
    this.nightMats.push(m);
    return m;
  }
  private nightMesh(mesh: THREE.Object3D) {
    this.nightMeshes.push(mesh);
    mesh.visible = this.nightK > 0.05;
    return mesh;
  }
  /** Additive material that only shows up after dark (neon signage). */
  neonMat(color: number, maxOpacity = 1) {
    const m = this.night(
      new THREE.MeshBasicMaterial({
        color,
        transparent: true,
        opacity: 0,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
      })
    );
    m.userData.maxOpacity = maxOpacity;
    return m;
  }
  /** Marks a mesh as night-only. */
  onlyAtNight<T extends THREE.Object3D>(mesh: T) {
    this.nightMeshes.push(mesh);
    mesh.visible = this.nightK > 0.05;
    return mesh;
  }
  /** Public hook so externally-built parts (the bike) join the day/night system. */
  registerNight(mat: THREE.Material, mesh: THREE.Object3D, maxOpacity = 1) {
    mat.userData.maxOpacity = maxOpacity;
    this.nightMats.push(mat);
    this.nightMeshes.push(mesh);
    (mat as THREE.MeshBasicMaterial).opacity = this.nightK * maxOpacity;
    mesh.visible = this.nightK > 0.05;
  }
  /** Registers a Lambert material with an emissiveMap (windows, signs, road paint). */
  lit(mat: THREE.MeshLambertMaterial) {
    this.emissiveMats.push(mat);
    mat.emissiveIntensity = this.nightK;
    return mat;
  }

  /** k = 0 bright day, 1 full night */
  setNight(k: number) {
    this.nightK = k;
    for (const m of this.emissiveMats) m.emissiveIntensity = k * 1.25;
    const vis = k > 0.05;
    for (const m of this.nightMats) {
      const mm = m as THREE.MeshBasicMaterial;
      mm.opacity = k * (mm.userData.maxOpacity ?? 1);
    }
    for (const o of this.nightMeshes) o.visible = vis;
  }

  // ---------------- road furniture ----------------
  private buildKerbGeo(): THREE.BufferGeometry {
    const parts: THREE.BufferGeometry[] = [];
    // under-deck
    parts.push(bx(ROAD_HALF * 2 + 0.6, 0.7, 6, 0, -0.36, 0, 0x6d6a63));
    // kerb stone
    parts.push(bx(ROAD_HALF * 2 + 0.5, 0.16, 6, 0, 0.06, 0, 0x8f8b82));
    for (const s of [-1, 1]) {
      const x = s * (ROAD_HALF + 0.3);
      // Armco guard rail
      parts.push(bx(0.14, 0.26, 6, x, 0.72, 0, 0xc3cad1));
      parts.push(bx(0.1, 0.14, 6, x, 0.46, 0, 0xaeb6bd));
      for (const z of [-2, 0, 2]) parts.push(bx(0.12, 0.8, 0.16, x, 0.42, z, 0x8d959c));
    }
    return mergeGeometries(parts)!;
  }

  private buildNeonStripGeo(): THREE.BufferGeometry {
    const parts: THREE.BufferGeometry[] = [];
    for (const s of [-1, 1]) parts.push(bx(0.07, 0.07, 6, s * (ROAD_HALF + 0.16), 0.2, 0, 0xffffff));
    return mergeGeometries(parts)!;
  }

  private buildLampGeo(): THREE.BufferGeometry {
    const parts: THREE.BufferGeometry[] = [];
    parts.push(bx(0.16, 0.3, 0.16, 0, 0.15, 0, 0x6f767d));
    parts.push(bx(0.13, 5.4, 0.13, 0, 2.85, 0, 0x9aa3ab));
    parts.push(bx(0.11, 0.11, 1.3, 0, 5.5, -0.6, 0x9aa3ab));
    parts.push(bx(0.42, 0.14, 0.9, 0, 5.38, -1.15, 0xd8dee4));
    return mergeGeometries(parts)!;
  }

  private buildTreeGeo(v: number): THREE.BufferGeometry {
    const parts: THREE.BufferGeometry[] = [];
    const h = 2.4 + (v % 3) * 0.7;
    const trunk = new THREE.CylinderGeometry(0.14, 0.22, h, 6);
    trunk.translate(0, h / 2, 0);
    parts.push(paint(trunk, 0x5b4432));
    const greens = [0x3f7a35, 0x4d8c3a, 0x2f6b32];
    const blobs = v === 1 ? 2 : 3;
    for (let i = 0; i < blobs; i++) {
      const r = 1.0 + ((i * 7 + v * 3) % 5) * 0.12;
      const s = new THREE.IcosahedronGeometry(r, 0);
      s.translate(((i * 13) % 7 - 3) * 0.12, h + r * 0.55 + i * 0.35, ((i * 5) % 3 - 1) * 0.14);
      parts.push(paint(s, greens[(i + v) % 3]));
    }
    return mergeGeometries(parts)!;
  }

  buildLamp(side: number): THREE.Group {
    const g = new THREE.Group();
    const pole = new THREE.Mesh(this.lampGeo, this.vcMat);
    pole.scale.x = side;
    g.add(pole);
    const glow = new THREE.Mesh(
      this.lampGlowGeo,
      this.night(
        new THREE.MeshBasicMaterial({
          map: this.glowTex,
          color: 0xffd9a0,
          transparent: true,
          opacity: 0,
          blending: THREE.AdditiveBlending,
          depthWrite: false,
        })
      )
    );
    glow.position.set(0, 5.2, side * -1.15);
    this.nightMesh(glow);
    g.add(glow);
    return g;
  }

  buildTree(v: number): THREE.Mesh {
    return new THREE.Mesh(this.treeGeos[v % this.treeGeos.length], this.vcMat);
  }

  // ---------------- obstacles ----------------
  build(kind: ObKind): THREE.Group {
    const g = new THREE.Group();
    switch (kind) {
      case 'barrier': {
        // concrete jersey barrier with reflective tape
        const s = new THREE.Shape();
        s.moveTo(-0.34, 0);
        s.lineTo(0.34, 0);
        s.lineTo(0.17, 0.92);
        s.lineTo(-0.17, 0.92);
        s.closePath();
        const geo = new THREE.ExtrudeGeometry(s, { depth: 2.0, bevelEnabled: false });
        geo.translate(0, 0, -1);
        geo.rotateY(Math.PI / 2);
        g.add(new THREE.Mesh(geo, this.concrete));
        g.add(this.part(2.0, 0.1, 0.02, this.hazardMat, 0, 0.72, 0.2));
        g.add(this.part(2.0, 0.1, 0.02, this.hazardMat, 0, 0.72, -0.2));
        for (const x of [-0.7, 0.7]) {
          const lamp = this.part(0.12, 0.12, 0.12, this.red, x, 0.99, 0);
          g.add(lamp);
          g.add(this.nightMesh(this.glowQuad(0.9, 0.9, 0xff4040, x, 1.0, 0.24)));
        }
        break;
      }
      case 'block': {
        // box truck: cab + trailer
        const paintC = pick([0xf2f2f2, 0xd8dade, 0x2f6fb0, 0xb41f24]);
        const parts: THREE.BufferGeometry[] = [
          bx(2.0, 1.45, 1.5, 0, 1.35, 1.75, paintC),
          bx(1.9, 0.55, 0.7, 0, 0.85, 2.5, paintC),
          bx(1.58, 0.06, 1.55, 0, 2.1, 1.75, paintC),
        ];
        g.add(new THREE.Mesh(mergeGeometries(parts)!, this.vcMat));
        g.add(this.part(1.72, 0.66, 0.08, this.glass, 0, 1.72, 2.48));
        const trailer: THREE.BufferGeometry[] = [bx(2.2, 2.35, 3.5, 0, 1.72, -0.75, 0xe4e6e8)];
        for (let i = 0; i < 5; i++) trailer.push(bx(2.24, 0.06, 0.08, 0, 1.72, -2.3 + i * 0.78, 0xc2c6ca));
        g.add(new THREE.Mesh(mergeGeometries(trailer)!, this.vcMat));
        g.add(this.part(2.16, 0.14, 3.4, this.hazardMat, 0, 0.62, -0.75));
        const dark: THREE.BufferGeometry[] = [
          bx(2.06, 0.32, 4.9, 0, 0.42, 0, 0x2a2d31),
          bx(2.02, 0.24, 0.2, 0, 0.5, 2.62, 0x2a2d31),
          bx(0.24, 0.5, 0.1, 0, 0.5, -2.52, 0x2a2d31),
        ];
        g.add(new THREE.Mesh(mergeGeometries(dark)!, this.vcMat));
        const wheels: THREE.BufferGeometry[] = [];
        for (const [x, z] of [
          [-0.86, 1.9],
          [0.86, 1.9],
          [-0.9, -0.4],
          [0.9, -0.4],
          [-0.9, -1.7],
          [0.9, -1.7],
        ] as const) {
          const w = this.wheelGeo.clone();
          w.scale(1, 1, 1);
          w.translate(x, 0.36, z);
          wheels.push(paint(w, 0x15161a));
          const h = this.hubGeo.clone();
          h.translate(x, 0.36, z);
          wheels.push(paint(h, 0x9aa3ab));
        }
        g.add(new THREE.Mesh(mergeGeometries(wheels)!, this.vcMat));
        g.add(this.part(0.5, 0.18, 0.06, this.white, -0.6, 0.95, 2.66));
        g.add(this.part(0.5, 0.18, 0.06, this.white, 0.6, 0.95, 2.66));
        g.add(this.nightMesh(this.glowQuad(2.6, 1.4, 0xfff2cc, 0, 0.95, 2.8)));
        g.add(this.part(1.7, 0.16, 0.06, this.red, 0, 0.9, -2.54));
        g.add(this.nightMesh(this.glowQuad(2.4, 1.0, 0xff3030, 0, 0.9, -2.7)));
        break;
      }
      case 'car': {
        const paintC = pick(CAR_PAINTS);
        const body: THREE.BufferGeometry[] = [
          bx(1.74, 0.54, 4.1, 0, 0.74, 0, paintC),
          bx(1.68, 0.3, 1.0, 0, 0.66, 1.9, paintC),
          bx(1.56, 0.07, 1.9, 0, 1.5, -0.1, paintC),
          bx(0.1, 0.44, 0.06, 0.79, 1.24, 0.8, paintC),
          bx(0.1, 0.44, 0.06, -0.79, 1.24, 0.8, paintC),
          bx(0.1, 0.44, 0.06, 0.79, 1.24, -1.05, paintC),
          bx(0.1, 0.44, 0.06, -0.79, 1.24, -1.05, paintC),
        ];
        g.add(new THREE.Mesh(mergeGeometries(body)!, this.vcMat));
        g.add(this.part(1.5, 0.5, 1.86, this.glass, 0, 1.24, -0.1));
        const trim: THREE.BufferGeometry[] = [
          bx(1.78, 0.22, 0.2, 0, 0.52, 2.06, 0x22262b),
          bx(1.78, 0.22, 0.2, 0, 0.52, -2.06, 0x22262b),
          bx(1.72, 0.1, 4.0, 0, 0.44, 0, 0x1b1e22),
          bx(0.18, 0.09, 0.12, 0.92, 1.2, 0.75, 0x22262b),
          bx(0.18, 0.09, 0.12, -0.92, 1.2, 0.75, 0x22262b),
        ];
        g.add(new THREE.Mesh(mergeGeometries(trim)!, this.vcMat));
        const wheels: THREE.BufferGeometry[] = [];
        for (const [x, z] of [
          [-0.82, 1.34],
          [0.82, 1.34],
          [-0.82, -1.36],
          [0.82, -1.36],
        ] as const) {
          const w = this.wheelGeo.clone();
          w.translate(x, 0.36, z);
          wheels.push(paint(w, 0x15161a));
          const h = this.hubGeo.clone();
          h.translate(x, 0.36, z);
          wheels.push(paint(h, 0xb9c0c6));
        }
        g.add(new THREE.Mesh(mergeGeometries(wheels)!, this.vcMat));
        g.add(this.part(0.42, 0.15, 0.06, this.white, -0.55, 0.8, 2.09));
        g.add(this.part(0.42, 0.15, 0.06, this.white, 0.55, 0.8, 2.09));
        g.add(this.part(0.42, 0.13, 0.06, this.red, -0.55, 0.84, -2.09));
        g.add(this.part(0.42, 0.13, 0.06, this.red, 0.55, 0.84, -2.09));
        g.add(this.nightMesh(this.glowQuad(2.4, 1.3, 0xfff4d0, 0, 0.8, 2.4)));
        g.add(this.nightMesh(this.glowQuad(2.0, 0.9, 0xff2a2a, 0, 0.84, -2.4)));
        break;
      }
      case 'laserLow': {
        // road-works steel beam spanning the carriageway - jump it
        for (const s of [-1, 1]) {
          g.add(this.part(0.7, 0.5, 0.7, this.concrete, s * (ROAD_HALF - 0.1), 0.25, 0));
          g.add(this.part(0.14, 0.7, 0.14, this.steel, s * (ROAD_HALF - 0.1), 0.6, 0));
        }
        g.add(this.part(ROAD_HALF * 2, 0.2, 0.24, this.steel, 0, 0.52, 0));
        g.add(this.part(ROAD_HALF * 2, 0.18, 0.26, this.hazardMat, 0, 0.3, 0));
        g.add(this.part(ROAD_HALF * 2, 0.06, 0.06, this.darkSteel, 0, 0.14, 0));
        for (const s of [-1, 1]) {
          g.add(this.part(0.14, 0.14, 0.14, this.red, s * 3.4, 0.7, 0));
          g.add(this.nightMesh(this.glowQuad(1.1, 1.1, 0xff4040, s * 3.4, 0.72, 0.2)));
        }
        break;
      }
      case 'laserHigh': {
        // low-clearance gantry with a highway sign - duck under it
        for (const s of [-1, 1]) {
          g.add(this.part(0.36, 5.4, 0.36, this.steel, s * (ROAD_HALF + 0.6), 2.7, 0));
          g.add(this.part(0.6, 0.2, 0.6, this.concrete, s * (ROAD_HALF + 0.6), 0.1, 0));
        }
        g.add(this.part(ROAD_HALF * 2 + 1.6, 0.34, 0.34, this.steel, 0, 5.2, 0));
        const signMat = this.lit(
          new THREE.MeshLambertMaterial({
            map: pick(this.signTex),
            emissive: 0xffffff,
            emissiveMap: undefined,
            emissiveIntensity: 0,
          })
        );
        signMat.emissiveMap = signMat.map;
        const sign = this.part(8.2, 2.1, 0.16, signMat, 0, 3.5, 0);
        g.add(sign);
        g.add(this.part(8.4, 0.24, 0.26, this.hazardMat, 0, 1.2, 0));
        g.add(this.part(8.4, 0.05, 0.28, this.darkSteel, 0, 1.06, 0));
        for (const s of [-1, 1]) g.add(this.part(0.06, 0.6, 0.06, this.darkSteel, s * 3.6, 2.15, 0));
        for (const s of [-1, 1]) {
          g.add(this.part(0.16, 0.16, 0.16, this.red, s * 4.1, 1.3, 0.16));
          g.add(this.nightMesh(this.glowQuad(1.2, 1.2, 0xff4040, s * 4.1, 1.3, 0.3)));
        }
        break;
      }
      case 'drone': {
        // security drone
        const bodyG = new THREE.OctahedronGeometry(0.42, 0);
        bodyG.scale(1.3, 0.7, 1.5);
        bodyG.translate(0, 1.0, 0);
        g.add(new THREE.Mesh(paint(bodyG, 0x2c3138), this.vcMat));
        const arms: THREE.BufferGeometry[] = [];
        for (const [x, z] of [
          [-0.62, -0.5],
          [0.62, -0.5],
          [-0.62, 0.5],
          [0.62, 0.5],
        ] as const) arms.push(bx(0.09, 0.07, 0.7, x * 0.55, 1.02, z * 0.55, 0x4a5058));
        g.add(new THREE.Mesh(mergeGeometries(arms)!, this.vcMat));
        const spin = new THREE.Group();
        spin.name = 'spin';
        for (const [x, z] of [
          [-0.62, -0.5],
          [0.62, -0.5],
          [-0.62, 0.5],
          [0.62, 0.5],
        ] as const) {
          const rotor = new THREE.Mesh(new THREE.BoxGeometry(0.86, 0.02, 0.07), this.darkSteel);
          rotor.position.set(x, 1.12, z);
          spin.add(rotor);
          const hub = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.09, 0.14, 6), this.steel);
          hub.position.set(x, 1.06, z);
          spin.add(hub);
        }
        g.add(spin);
        const eye = new THREE.Mesh(new THREE.SphereGeometry(0.15, 10, 8), this.red);
        eye.position.set(0, 0.98, 0.5);
        g.add(eye);
        const cone = new THREE.Mesh(
          new THREE.ConeGeometry(0.9, 1.5, 12, 1, true),
          this.night(
            new THREE.MeshBasicMaterial({
              color: 0xffe9b0,
              transparent: true,
              opacity: 0,
              blending: THREE.AdditiveBlending,
              depthWrite: false,
              side: THREE.DoubleSide,
            })
          )
        );
        cone.position.set(0, 0.25, 0.4);
        cone.rotation.x = Math.PI;
        this.nightMesh(cone);
        g.add(cone);
        break;
      }
      case 'gapEdge': {
        g.add(this.part(ROAD_HALF * 2, 0.12, 0.35, this.hazardMat, 0, 0.02, 0));
        break;
      }
    }
    return g;
  }

  private part(w: number, h: number, d: number, mat: THREE.Material, x = 0, y = 0, z = 0) {
    const m = new THREE.Mesh(this.boxGeo, mat);
    m.scale.set(w, h, d);
    m.position.set(x, y, z);
    return m;
  }

  private glowQuad(w: number, h: number, color: number, x = 0, y = 0, z = 0) {
    const m = new THREE.Mesh(
      new THREE.PlaneGeometry(w, h),
      this.night(
        new THREE.MeshBasicMaterial({
          map: this.glowTex,
          color,
          transparent: true,
          opacity: 0,
          blending: THREE.AdditiveBlending,
          depthWrite: false,
        })
      )
    );
    m.position.set(x, y, z);
    return m;
  }

  buildPower(kind: PowerKind): THREE.Group {
    const p = POWERS[kind];
    const g = new THREE.Group();
    const core = new THREE.Mesh(new THREE.IcosahedronGeometry(0.42, 0), new THREE.MeshBasicMaterial({ color: p.color }));
    core.name = 'core';
    g.add(core);
    const shell = new THREE.Mesh(
      new THREE.IcosahedronGeometry(0.7, 1),
      new THREE.MeshBasicMaterial({ color: p.color, wireframe: true, transparent: true, opacity: 0.6 })
    );
    shell.name = 'shell';
    g.add(shell);
    const glow = new THREE.Sprite(
      new THREE.SpriteMaterial({ map: this.glowTex, color: p.color, blending: THREE.AdditiveBlending, depthWrite: false })
    );
    glow.scale.setScalar(3);
    g.add(glow);
    return g;
  }

  buildDecal(kind: DecalKind): THREE.Group {
    const g = new THREE.Group();
    const flat = (mesh: THREE.Mesh, y = 0.02) => {
      mesh.rotation.x = -Math.PI / 2;
      mesh.position.y = y;
      g.add(mesh);
      return mesh;
    };
    const glowMat = (c: number, op = 1) =>
      new THREE.MeshBasicMaterial({
        color: c,
        transparent: op < 1,
        opacity: op,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
        side: THREE.DoubleSide,
      });
    const paintMat = (c: number) => new THREE.MeshBasicMaterial({ color: c, side: THREE.DoubleSide });

    if (kind === 'arrow') {
      // tip at +y in shape space == forward (-z) once laid flat
      const s = new THREE.Shape();
      s.moveTo(0, 1.5);
      s.lineTo(0.85, -0.1);
      s.lineTo(0.32, -0.1);
      s.lineTo(0.32, -1.5);
      s.lineTo(-0.32, -1.5);
      s.lineTo(-0.32, -0.1);
      s.lineTo(-0.85, -0.1);
      s.closePath();
      flat(new THREE.Mesh(new THREE.ShapeGeometry(s), paintMat(0xf6fbff)));
      const halo = new THREE.Mesh(new THREE.ShapeGeometry(s.clone()), glowMat(0x35e6ff, 0.55));
      halo.scale.setScalar(1.55);
      flat(halo, 0.015);
    } else if (kind === 'pad') {
      for (let i = 0; i < 3; i++) {
        const s = new THREE.Shape();
        const w = 1.05;
        s.moveTo(-w, -0.34);
        s.lineTo(0, 0.34);
        s.lineTo(w, -0.34);
        s.lineTo(w, 0.02);
        s.lineTo(0, 0.7);
        s.lineTo(-w, 0.02);
        s.closePath();
        const m = flat(new THREE.Mesh(new THREE.ShapeGeometry(s), paintMat(i === 1 ? 0xffd23f : 0xffffff)), 0.02 + i * 0.001);
        m.position.z = (i - 1) * 0.95;
      }
      flat(new THREE.Mesh(new THREE.PlaneGeometry(2.4, 3.4), glowMat(0xff2bd6, 0.35)), 0.012);
    } else if (kind === 'ramp') {
      const s = new THREE.Shape();
      s.moveTo(-1.6, 0);
      s.lineTo(1.6, 0);
      s.lineTo(1.6, 0.95);
      s.closePath();
      const geo = new THREE.ExtrudeGeometry(s, { depth: 2.0, bevelEnabled: false });
      geo.translate(0, 0, -1);
      geo.rotateY(Math.PI / 2);
      g.add(new THREE.Mesh(geo, this.concrete));
      g.add(new THREE.LineSegments(new THREE.EdgesGeometry(geo), new THREE.LineBasicMaterial({ color: 0x2b2f34 })));
      for (let i = 0; i < 3; i++) {
        const strip = this.part(1.9, 0.05, 0.18, this.hazardMat, 0, 0.07 + i * 0.28, 1.2 - i * 0.85);
        strip.rotation.x = -0.3;
        g.add(strip);
      }
    } else if (kind === 'warn') {
      flat(new THREE.Mesh(new THREE.PlaneGeometry(ROAD_HALF * 2, 1.5), this.hazardMat), 0.02);
      flat(new THREE.Mesh(new THREE.PlaneGeometry(ROAD_HALF * 2.2, 2.4), glowMat(0xff2050, 0.28)), 0.014);
    }
    return g;
  }

  buildTunnel(): THREE.Group {
    const g = new THREE.Group();
    const parts: THREE.BufferGeometry[] = [
      bx(ROAD_HALF * 2 + 2.6, 0.4, 6, 0, 6.5, 0, 0x7d7a72),
      bx(0.5, 6.5, 6, -(ROAD_HALF + 1.1), 3.25, 0, 0x6f6c65),
      bx(0.5, 6.5, 6, ROAD_HALF + 1.1, 3.25, 0, 0x6f6c65),
    ];
    for (const z of [-2.2, 0, 2.2]) {
      parts.push(bx(ROAD_HALF * 2 + 2.6, 0.14, 0.22, 0, 6.28, z, 0x8f8c84));
      parts.push(bx(0.14, 6.2, 0.22, -(ROAD_HALF + 0.82), 3.2, z, 0x8f8c84));
      parts.push(bx(0.14, 6.2, 0.22, ROAD_HALF + 0.82, 3.2, z, 0x8f8c84));
    }
    g.add(new THREE.Mesh(mergeGeometries(parts)!, this.vcMat));
    const stripMat = this.night(
      new THREE.MeshBasicMaterial({
        color: 0xfff0c8,
        transparent: true,
        opacity: 0,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
      })
    );
    for (const z of [-2, 0, 2]) {
      const strip = this.part(ROAD_HALF * 1.6, 0.06, 0.3, stripMat, 0, 6.26, z);
      this.nightMesh(strip);
      g.add(strip);
    }
    // daytime fluorescent tubes
    for (const z of [-2, 0, 2]) g.add(this.part(ROAD_HALF * 1.6, 0.07, 0.24, lambert(0xdfe6ea), 0, 6.24, z));
    return g;
  }

  buildBridge(): THREE.Group {
    const g = new THREE.Group();
    const parts: THREE.BufferGeometry[] = [];
    for (const s of [-1, 1]) {
      const x = s * (ROAD_HALF + 0.7);
      parts.push(bx(0.28, 9, 0.28, x, 4.5, 0, 0x8d959c));
      parts.push(bx(0.08, 9, 0.08, x - s * 0.18, 4.5, 0, 0xb6bdc4));
      for (let i = 0; i < 5; i++) {
        const z = -2.6 + i * 1.3;
        const h = 1.2 + Math.abs(2 - i) * 0.55;
        parts.push(bx(0.05, h, 0.05, x - s * 0.1, 1.3 + h / 2, z, 0xa9b1b8));
      }
    }
    g.add(new THREE.Mesh(mergeGeometries(parts)!, this.vcMat));
    return g;
  }

  buildGapLip(side: number): THREE.Group {
    const g = new THREE.Group();
    const ze = side * 0.02;
    g.add(this.part(ROAD_HALF * 2, 0.14, 0.5, this.hazardMat, 0, 0.01, ze));
    g.add(this.part(ROAD_HALF * 2, 0.5, 0.24, this.concrete, 0, -0.28, ze - side * 0.3));
    const pitMat = lambert(0x2b2620, { side: THREE.DoubleSide });
    g.add(this.part(ROAD_HALF * 2 + 0.3, 13, 0.3, pitMat, 0, -6.5, ze - side * 0.45));
    for (const x of [-ROAD_HALF - 0.15, ROAD_HALF + 0.15]) {
      g.add(this.part(0.3, 13, 0.3, pitMat, x, -6.5, ze - side * 0.45));
    }
    for (let i = 0; i < 5; i++) {
      const x = -ROAD_HALF + 0.9 + i * ((ROAD_HALF * 2 - 1.8) / 4);
      const h = 0.35 + ((i * 37) % 5) * 0.11;
      const spike = this.part(0.07, h, 0.07, this.steel, x, -h / 2 + 0.05, ze - side * 0.1);
      spike.rotation.z = ((i % 2) - 0.5) * 0.35;
      g.add(spike);
    }
    const pts: THREE.Vector3[] = [];
    for (let i = 0; i <= 8; i++) {
      const t = i / 8;
      pts.push(new THREE.Vector3(-1.6 + t * 3.2, -0.2 - Math.sin(t * Math.PI) * 1.1, ze - side * 0.2));
    }
    g.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts), new THREE.LineBasicMaterial({ color: 0x2b2f34 })));
    const glow = this.glowQuad(ROAD_HALF * 2.6, 2.6, 0xff3030, 0, 0.05, ze - side * 0.3);
    glow.rotation.x = -Math.PI / 2;
    glow.name = 'glow';
    g.add(glow);
    for (const s of [-1, 1]) {
      g.add(this.part(0.28, 1.1, 0.28, this.steel, s * ROAD_HALF, 0.55, ze));
      const lamp = this.part(0.16, 0.14, 0.16, this.red, s * ROAD_HALF, 1.14, ze);
      g.add(lamp);
      g.add(this.nightMesh(this.glowQuad(1.1, 1.1, 0xff4040, s * ROAD_HALF, 1.16, ze + 0.2)));
    }
    return g;
  }
}

/* ---------------- player bike ---------------- */

export interface BikeModel {
  group: THREE.Group;
  wheels: THREE.Object3D[];
  body: THREE.Group;
  shield: THREE.Mesh;
  magnetRing: THREE.Mesh;
  underGlow: THREE.Mesh;
  headCone: THREE.Mesh;
}

export function buildBike(
  def: BikeDef,
  glowTex: THREE.Texture,
  nightCb: (m: THREE.Material, mesh: THREE.Object3D, maxOpacity: number) => void
): BikeModel {
  const group = new THREE.Group();
  const body = new THREE.Group();
  group.add(body);
  const L = def.length;
  const paintC = def.body;
  const chrome = lambert(0xc7ced4);
  const dark = lambert(0x1a1c20);
  const rubber = lambert(0x121316);
  const accent = new THREE.MeshBasicMaterial({ color: def.glow });
  const paintMat = lambert(paintC, { emissive: paintC, emissiveIntensity: 0.12 });

  const add = (m: THREE.Object3D) => {
    body.add(m);
    return m;
  };
  const box = (w: number, h: number, d: number, mat: THREE.Material, x: number, y: number, z: number) => {
    const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
    m.position.set(x, y, z);
    return add(m);
  };

  // wheels: real tyres + spoked rims
  const wheels: THREE.Object3D[] = [];
  const wheelR = 0.42;
  for (const z of [-(L / 2 - 0.36), L / 2 - 0.36]) {
    const w = new THREE.Group();
    w.position.set(0, wheelR, z);
    const tyre = new THREE.Mesh(new THREE.TorusGeometry(wheelR, 0.11, 8, 22), rubber);
    tyre.rotation.y = Math.PI / 2;
    w.add(tyre);
    const rim = new THREE.Mesh(new THREE.CylinderGeometry(wheelR - 0.09, wheelR - 0.09, 0.14, 14), chrome);
    rim.rotation.z = Math.PI / 2;
    w.add(rim);
    for (let i = 0; i < 5; i++) {
      const sp = new THREE.Mesh(new THREE.BoxGeometry(0.06, wheelR * 1.5, 0.04), chrome);
      sp.rotation.x = (i / 5) * Math.PI;
      w.add(sp);
    }
    body.add(w);
    wheels.push(w);
  }

  // frame, tank, seat, engine
  box(0.16, 0.16, L * 0.7, chrome, 0, 0.62, 0);
  box(0.4, 0.3, 0.62, dark, 0, 0.56, 0.16);
  const tank = box(0.44, 0.3, 0.78, paintMat, 0, 0.86, -0.16);
  tank.rotation.x = -0.12;
  box(0.34, 0.12, 0.5, dark, 0, 0.94, 0.34);
  box(0.3, 0.1, 0.34, dark, 0, 0.9, 0.62);
  // fairing / nose
  const nose = box(0.4, 0.34, 0.62, paintMat, 0, 0.82, -L / 2 + 0.24);
  nose.rotation.x = 0.42;
  const screen = box(
    0.34,
    0.22,
    0.05,
    new THREE.MeshLambertMaterial({ color: 0x22303a, transparent: true, opacity: 0.75 }),
    0,
    1.02,
    -L / 2 + 0.06
  );
  screen.rotation.x = 0.5;
  // forks + bars
  for (const s of [-1, 1]) {
    const fork = box(0.07, 0.72, 0.07, chrome, s * 0.17, 0.72, -L / 2 + 0.36);
    fork.rotation.x = 0.35;
    const bar = box(0.3, 0.05, 0.05, chrome, s * 0.26, 1.06, -L / 2 + 0.62);
    bar.rotation.z = s * 0.2;
    box(0.1, 0.07, 0.07, dark, s * 0.4, 1.08, -L / 2 + 0.62);
    const mirror = box(0.1, 0.07, 0.05, chrome, s * 0.42, 1.2, -L / 2 + 0.6);
    mirror.rotation.y = s * 0.3;
  }
  // exhaust
  const pipe = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.1, 0.85, 8), chrome);
  pipe.rotation.x = Math.PI / 2;
  pipe.position.set(0.24, 0.42, 0.5);
  add(pipe);
  box(0.1, 0.14, 0.16, dark, 0.24, 0.42, 0.94);
  // lights
  const head = box(0.2, 0.14, 0.06, new THREE.MeshBasicMaterial({ color: 0xfff6dd }), 0, 0.9, -L / 2 - 0.02);
  head.name = 'head';
  box(0.16, 0.07, 0.05, new THREE.MeshBasicMaterial({ color: 0xff2a2a }), 0, 0.92, L / 2 + 0.02);
  // accent strips (the bike's signature colour)
  box(0.03, 0.05, L * 0.62, accent, 0.21, 0.72, 0.05);
  box(0.03, 0.05, L * 0.62, accent, -0.21, 0.72, 0.05);
  box(0.42, 0.03, 0.05, accent, 0, 0.68, -L / 2 + 0.5);

  // rider
  const jacket = lambert(0x2a2f3a, { emissive: 0x0a0d14 });
  const torso = box(0.4, 0.52, 0.3, jacket, 0, 1.14, 0.16);
  torso.rotation.x = -0.8;
  box(0.34, 0.3, 0.16, lambert(0x3a4150), 0, 1.24, 0.42).rotation.x = -0.8;
  const helmet = new THREE.Mesh(new THREE.SphereGeometry(0.185, 14, 12), lambert(0xf0f2f5));
  helmet.position.set(0, 1.34, -0.06);
  helmet.scale.set(1, 1.05, 1.15);
  add(helmet);
  const visor = new THREE.Mesh(new THREE.SphereGeometry(0.16, 12, 10, 0, Math.PI, 0.6, 0.9), lambert(0x101820));
  visor.position.set(0, 1.36, -0.08);
  visor.rotation.y = Math.PI;
  add(visor);
  box(0.36, 0.05, 0.05, accent, 0, 1.2, -0.16);
  for (const s of [-1, 1]) {
    const arm = box(0.1, 0.36, 0.1, jacket, s * 0.2, 1.16, -0.06);
    arm.rotation.x = -1.1;
    arm.rotation.z = s * 0.25;
    const leg = box(0.12, 0.42, 0.12, lambert(0x22262e), s * 0.2, 0.86, 0.42);
    leg.rotation.x = 0.9;
    box(0.13, 0.1, 0.24, dark, s * 0.2, 0.62, 0.62);
  }

  // night bits: underglow + headlight cone
  const underGlow = new THREE.Mesh(
    new THREE.PlaneGeometry(2.2, L + 1.6),
    new THREE.MeshBasicMaterial({
      map: glowTex,
      color: def.glow,
      transparent: true,
      opacity: 0.6,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    })
  );
  underGlow.rotation.x = -Math.PI / 2;
  underGlow.position.y = 0.04;
  group.add(underGlow);

  const headCone = new THREE.Mesh(
    new THREE.ConeGeometry(2.0, 9, 14, 1, true),
    new THREE.MeshBasicMaterial({
      color: 0xfff2cc,
      transparent: true,
      opacity: 0,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      side: THREE.DoubleSide,
    })
  );
  headCone.rotation.x = -Math.PI / 2;
  headCone.position.set(0, 0.55, -L / 2 - 4.4);
  group.add(headCone);
  nightCb(headCone.material, headCone, 0.15);
  nightCb(underGlow.material, underGlow, 0.7);

  const shield = new THREE.Mesh(
    new THREE.IcosahedronGeometry(1.45, 2),
    new THREE.MeshBasicMaterial({
      color: 0x5dff6a,
      wireframe: true,
      transparent: true,
      opacity: 0.45,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    })
  );
  shield.position.y = 0.8;
  shield.scale.set(0.8, 0.8, 1.15);
  shield.visible = false;
  group.add(shield);

  const magnetRing = new THREE.Mesh(
    new THREE.TorusGeometry(1.3, 0.04, 6, 40),
    new THREE.MeshBasicMaterial({ color: 0x3fa9ff, transparent: true, opacity: 0.8, blending: THREE.AdditiveBlending })
  );
  magnetRing.rotation.x = Math.PI / 2;
  magnetRing.position.y = 0.1;
  magnetRing.visible = false;
  group.add(magnetRing);

  return { group, wheels, body, shield, magnetRing, underGlow, headCone };
}

export const BIKE_NIGHT_OPACITY: Record<string, number> = { headCone: 0.16, underGlow: 0.7 };
