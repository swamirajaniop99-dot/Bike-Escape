export const LANE_X = [-2.4, 0, 2.4];
export const TILE_LEN = 6;
export const ROAD_HALF = 4.2;
export const SPAWN_DIST = 170;
export const BASE_SPEED = 28;
export const MAX_SPEED = 64;
export const GRAVITY = 40;

export type PowerKind = 'magnet' | 'shield' | 'boost' | 'multi';
export type TimePref = 'day' | 'cycle' | 'night';

export interface BikeDef {
  id: string;
  name: string;
  tagline: string;
  price: number;
  body: number;
  glow: number;
  accent: number;
  css: string;
  handling: number; // lane switch speed multiplier
  jump: number; // jump height multiplier
  magnet: number; // power-up duration multiplier
  coinMult: number;
  startShield: boolean;
  length: number;
  perk: string;
}

export const BIKES: BikeDef[] = [
  {
    id: 'volt',
    name: 'VOLT-1',
    tagline: 'Standard-issue escape cycle',
    price: 0,
    body: 0x10131f,
    glow: 0x22f3ff,
    accent: 0xffffff,
    css: '#22f3ff',
    handling: 1,
    jump: 1,
    magnet: 1,
    coinMult: 1,
    startShield: false,
    length: 2.0,
    perk: 'Balanced all-rounder',
  },
  {
    id: 'rift',
    name: 'RIFT',
    tagline: 'Twitchy street racer',
    price: 120,
    body: 0x1a0b1f,
    glow: 0xff2bd6,
    accent: 0xffd1f5,
    css: '#ff2bd6',
    handling: 1.3,
    jump: 1.08,
    magnet: 1,
    coinMult: 1,
    startShield: false,
    length: 1.9,
    perk: '+30% handling, higher jumps',
  },
  {
    id: 'solar',
    name: 'SOLAR FLARE',
    tagline: 'Built for power junkies',
    price: 350,
    body: 0x1f1208,
    glow: 0xff8a1f,
    accent: 0xffe2a8,
    css: '#ff8a1f',
    handling: 1.1,
    jump: 1.05,
    magnet: 1.6,
    coinMult: 1,
    startShield: false,
    length: 2.15,
    perk: 'Power-ups last 60% longer',
  },
  {
    id: 'phantom',
    name: 'PHANTOM',
    tagline: 'Armored ghost of the grid',
    price: 750,
    body: 0x07150c,
    glow: 0x5dff6a,
    accent: 0xd8ffd9,
    css: '#5dff6a',
    handling: 1.2,
    jump: 1.1,
    magnet: 1.2,
    coinMult: 1,
    startShield: true,
    length: 2.1,
    perk: 'Starts every run shielded',
  },
  {
    id: 'nova',
    name: 'NOVA PRIME',
    tagline: 'The legend. Pure light.',
    price: 1500,
    body: 0x1a1606,
    glow: 0xffe14d,
    accent: 0xffffff,
    css: '#ffe14d',
    handling: 1.35,
    jump: 1.12,
    magnet: 1.4,
    coinMult: 2,
    startShield: true,
    length: 2.25,
    perk: 'x2 coins, shield, elite handling',
  },
];

export const POWERS: Record<PowerKind, { color: number; css: string; label: string; duration: number; icon: string }> = {
  magnet: { color: 0x3fa9ff, css: '#3fa9ff', label: 'MAGNET', duration: 9, icon: '🧲' },
  shield: { color: 0x5dff6a, css: '#5dff6a', label: 'SHIELD', duration: 0, icon: '🛡️' },
  boost: { color: 0xff2bd6, css: '#ff2bd6', label: 'HYPER BOOST', duration: 4.5, icon: '⚡' },
  multi: { color: 0xffe14d, css: '#ffe14d', label: '2X SCORE', duration: 10, icon: '✖2' },
};

export function getBike(id: string): BikeDef {
  return BIKES.find((b) => b.id === id) ?? BIKES[0];
}
