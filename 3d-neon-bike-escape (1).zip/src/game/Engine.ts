import * as THREE from 'three';
import {
  BASE_SPEED,
  GRAVITY,
  LANE_X,
  MAX_SPEED,
  POWERS,
  ROAD_HALF,
  SPAWN_DIST,
  TILE_LEN,
  getBike,
  type BikeDef,
  type PowerKind,
  type TimePref,
} from './config';
import { Models, buildBike, type BikeModel, type DecalKind, type ObKind, type TileVariant } from './models';
import * as TX from './textures';
import { sfx } from './audio';

export type GameState = 'menu' | 'playing' | 'paused' | 'dying' | 'over';

export interface RunStats {
  score: number;
  distance: number;
  coins: number;
  nearMisses: number;
  maxCombo: number;
  time: number;
  bikeId: string;
}

export interface Hud {
  score?: HTMLElement | null;
  coins?: HTMLElement | null;
  dist?: HTMLElement | null;
  speed?: HTMLElement | null;
  combo?: HTMLElement | null;
  mult?: HTMLElement | null;
  popups?: HTMLElement | null;
  flash?: HTMLElement | null;
  vignette?: HTMLElement | null;
  powers?: Partial<Record<PowerKind, HTMLElement | null>>;
}

interface Callbacks {
  onState: (s: GameState) => void;
  onGameOver: (stats: RunStats) => void;
}

interface Obstacle {
  kind: ObKind;
  mesh: THREE.Group;
  x: number;
  z: number;
  w: number;
  d: number;
  y0: number;
  y1: number;
  vz: number;
  laneA: number;
  laneB: number;
  phase: number;
  passed: boolean;
  minSep: number;
  sepType: number; // 0 side, 1 over, 2 under
  solid: boolean;
}
interface Coin {
  x: number;
  y: number;
  z: number;
  alive: boolean;
}
interface Power {
  kind: PowerKind;
  mesh: THREE.Group;
  x: number;
  y: number;
  z: number;
}
interface Tile {
  mesh: THREE.Group;
  z: number;
  variant: TileVariant;
}
interface Decal {
  kind: DecalKind;
  mesh: THREE.Group;
  x: number;
  z: number;
  dead: boolean;
}
interface Lip {
  mesh: THREE.Group;
  z: number;
}
interface Gap {
  z0: number;
  z1: number;
}
interface Scenery {
  group: THREE.Group;
  z: number;
  depth: number;
}

const OB_DIMS: Record<ObKind, { w: number; d: number; y0: number; y1: number; solid: boolean }> = {
  barrier: { w: 2.0, d: 0.5, y0: 0, y1: 0.95, solid: true },
  block: { w: 2.1, d: 5.2, y0: 0, y1: 3.4, solid: true },
  car: { w: 1.9, d: 4.2, y0: 0, y1: 1.7, solid: true },
  laserLow: { w: 9, d: 0.3, y0: 0, y1: 0.65, solid: true },
  laserHigh: { w: 9, d: 0.4, y0: 1.1, y1: 6, solid: true },
  drone: { w: 1.8, d: 1.6, y0: 0.3, y1: 1.5, solid: true },
  gapEdge: { w: 0, d: 0, y0: 0, y1: 0, solid: false },
};

const NEAR_THRESH: Partial<Record<ObKind, number>> = {
  barrier: 0.7,
  block: 1.05,
  car: 1.1,
  drone: 1.2,
  laserLow: 0.55,
  laserHigh: 0.6,
};

const rand = (a: number, b: number) => a + Math.random() * (b - a);
const lerpC = (out: THREE.Color, a: number, b: number, t: number) =>
  out.copy(TOD_TMP_A.setHex(a)).lerp(TOD_TMP_B.setHex(b), t);
const TOD_TMP_A = new THREE.Color();
const TOD_TMP_B = new THREE.Color();
const randInt = (n: number) => Math.floor(Math.random() * n);
const pick = <T,>(a: T[]) => a[Math.floor(Math.random() * a.length)];

/** Time-of-day keyframes: bright day -> golden hour -> dusk -> neon night. */
const TOD_KEYS = [
  { t: 0.0, top: 0x2f7fd4, bot: 0xd9eaf8, fog: 0xc8dcec, fogN: 70, fogF: 470, hSky: 0xc6dcf4, hGnd: 0x77735f, hI: 1.45, sC: 0xfff4dd, sI: 2.2, sY: 95, sS: 70, amb: 0.32, road: 0xffffff, ground: 0xc6d6ae, cloud: 0.9, night: 0 },
  { t: 0.42, top: 0x2d4a86, bot: 0xff9d55, fog: 0xd9926a, fogN: 55, fogF: 400, hSky: 0xffb27a, hGnd: 0x54404a, hI: 1.05, sC: 0xff8a3c, sI: 1.75, sY: 26, sS: 150, amb: 0.24, road: 0xd8cfd6, ground: 0xa98a72, cloud: 0.75, night: 0.25 },
  { t: 0.64, top: 0x131a44, bot: 0x6b2a63, fog: 0x4a2352, fogN: 40, fogF: 330, hSky: 0x8f7cc0, hGnd: 0x2a1c33, hI: 0.85, sC: 0xc9a6ff, sI: 0.9, sY: 42, sS: 165, amb: 0.2, road: 0x9d94b8, ground: 0x6a4f86, cloud: 0.35, night: 0.7 },
  { t: 1.0, top: 0x05030f, bot: 0x2a0b45, fog: 0x1d0736, fogN: 26, fogF: 220, hSky: 0x6a5aa8, hGnd: 0x120826, hI: 0.8, sC: 0x9fc8ff, sI: 0.55, sY: 62, sS: 178, amb: 0.16, road: 0x8f86b4, ground: 0x4a2f7a, cloud: 0.08, night: 1 },
];
const round6 = (v: number) => Math.ceil(v / TILE_LEN) * TILE_LEN;
const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));

// ---------------- Particles ----------------
class Particles {
  readonly max = 900;
  pos = new Float32Array(this.max * 3);
  vel = new Float32Array(this.max * 3);
  col = new Float32Array(this.max * 3);
  size = new Float32Array(this.max);
  base = new Float32Array(this.max);
  alpha = new Float32Array(this.max);
  life = new Float32Array(this.max);
  maxLife = new Float32Array(this.max);
  grav = new Float32Array(this.max);
  geo = new THREE.BufferGeometry();
  mat: THREE.ShaderMaterial;
  points: THREE.Points;
  next = 0;
  private c = new THREE.Color();

  constructor() {
    for (let i = 0; i < this.max; i++) this.pos[i * 3 + 1] = -9999;
    const dyn = (a: THREE.BufferAttribute) => a.setUsage(THREE.DynamicDrawUsage);
    this.geo.setAttribute('position', dyn(new THREE.BufferAttribute(this.pos, 3)));
    this.geo.setAttribute('aColor', dyn(new THREE.BufferAttribute(this.col, 3)));
    this.geo.setAttribute('aSize', dyn(new THREE.BufferAttribute(this.size, 1)));
    this.geo.setAttribute('aAlpha', dyn(new THREE.BufferAttribute(this.alpha, 1)));
    this.mat = new THREE.ShaderMaterial({
      uniforms: { uScale: { value: 500 } },
      vertexShader: `
        attribute vec3 aColor; attribute float aSize; attribute float aAlpha;
        uniform float uScale; varying vec3 vColor; varying float vAlpha;
        void main(){ vColor=aColor; vAlpha=aAlpha;
          vec4 mv = modelViewMatrix*vec4(position,1.0);
          gl_PointSize = aSize*uScale/max(0.2,-mv.z);
          gl_Position = projectionMatrix*mv; }`,
      fragmentShader: `
        varying vec3 vColor; varying float vAlpha;
        void main(){ vec2 c = gl_PointCoord-0.5; float d = length(c); if(d>0.5) discard;
          float a = pow(1.0-d*2.0, 1.6);
          gl_FragColor = vec4(vColor*(0.8+a*0.8), a*vAlpha); }`,
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
    });
    this.points = new THREE.Points(this.geo, this.mat);
    this.points.frustumCulled = false;
  }

  emit(x: number, y: number, z: number, vx: number, vy: number, vz: number, color: number, size: number, life: number, grav = 0) {
    const i = this.next;
    this.next = (this.next + 1) % this.max;
    const i3 = i * 3;
    this.pos[i3] = x;
    this.pos[i3 + 1] = y;
    this.pos[i3 + 2] = z;
    this.vel[i3] = vx;
    this.vel[i3 + 1] = vy;
    this.vel[i3 + 2] = vz;
    this.c.set(color);
    this.col[i3] = this.c.r;
    this.col[i3 + 1] = this.c.g;
    this.col[i3 + 2] = this.c.b;
    this.base[i] = size;
    this.size[i] = size;
    this.life[i] = life;
    this.maxLife[i] = life;
    this.alpha[i] = 1;
    this.grav[i] = grav;
  }

  burst(x: number, y: number, z: number, n: number, color: number, speed: number, size: number, life: number, grav = 0, up = 0) {
    for (let k = 0; k < n; k++) {
      const u = Math.random() * 2 - 1;
      const th = Math.random() * Math.PI * 2;
      const r = Math.sqrt(1 - u * u);
      const s = speed * rand(0.3, 1);
      this.emit(x, y, z, r * Math.cos(th) * s, u * s + up, r * Math.sin(th) * s, color, size * rand(0.6, 1.2), life * rand(0.6, 1.2), grav);
    }
  }

  update(dt: number, worldDz: number) {
    const drag = Math.exp(-1.8 * dt);
    for (let i = 0; i < this.max; i++) {
      if (this.life[i] <= 0) continue;
      this.life[i] -= dt;
      const i3 = i * 3;
      if (this.life[i] <= 0) {
        this.alpha[i] = 0;
        this.pos[i3 + 1] = -9999;
        continue;
      }
      this.vel[i3 + 1] -= this.grav[i] * dt;
      this.vel[i3] *= drag;
      this.vel[i3 + 1] *= drag;
      this.vel[i3 + 2] *= drag;
      this.pos[i3] += this.vel[i3] * dt;
      this.pos[i3 + 1] += this.vel[i3 + 1] * dt;
      this.pos[i3 + 2] += this.vel[i3 + 2] * dt + worldDz;
      const t = this.life[i] / this.maxLife[i];
      this.alpha[i] = t;
      this.size[i] = this.base[i] * (0.4 + 0.6 * t);
    }
    (this.geo.attributes.position as THREE.BufferAttribute).needsUpdate = true;
    (this.geo.attributes.aColor as THREE.BufferAttribute).needsUpdate = true;
    (this.geo.attributes.aSize as THREE.BufferAttribute).needsUpdate = true;
    (this.geo.attributes.aAlpha as THREE.BufferAttribute).needsUpdate = true;
  }

  clear() {
    for (let i = 0; i < this.max; i++) {
      this.life[i] = 0;
      this.alpha[i] = 0;
      this.pos[i * 3 + 1] = -9999;
    }
  }
}

// ---------------- Light trail ----------------
class Trail {
  readonly n = 44;
  xs = new Float32Array(this.n);
  ys = new Float32Array(this.n);
  zs = new Float32Array(this.n);
  pos: Float32Array;
  col: Float32Array;
  geo = new THREE.BufferGeometry();
  mesh: THREE.Mesh;
  color = new THREE.Color();
  width = 1;

  constructor() {
    this.pos = new Float32Array(this.n * 2 * 3);
    this.col = new Float32Array(this.n * 2 * 3);
    const idx: number[] = [];
    for (let i = 0; i < this.n - 1; i++) {
      const a = i * 2;
      idx.push(a, a + 1, a + 2, a + 1, a + 3, a + 2);
    }
    this.geo.setIndex(idx);
    this.geo.setAttribute('position', new THREE.BufferAttribute(this.pos, 3).setUsage(THREE.DynamicDrawUsage));
    this.geo.setAttribute('color', new THREE.BufferAttribute(this.col, 3).setUsage(THREE.DynamicDrawUsage));
    this.mesh = new THREE.Mesh(
      this.geo,
      new THREE.MeshBasicMaterial({
        vertexColors: true,
        transparent: true,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
        side: THREE.DoubleSide,
      })
    );
    this.mesh.frustumCulled = false;
    for (let i = 0; i < this.n; i++) this.zs[i] = 100;
  }

  reset(x: number, y: number) {
    for (let i = 0; i < this.n; i++) {
      this.xs[i] = x;
      this.ys[i] = y;
      this.zs[i] = 1 + i * 0.3;
    }
  }

  update(worldDz: number, x: number, y: number, rearZ: number, maxLen: number) {
    for (let i = this.n - 1; i > 0; i--) {
      this.xs[i] = this.xs[i - 1];
      this.ys[i] = this.ys[i - 1];
      this.zs[i] = this.zs[i - 1] + worldDz;
    }
    this.xs[0] = x;
    this.ys[0] = y;
    this.zs[0] = rearZ;
    const r = this.color.r,
      g = this.color.g,
      b = this.color.b;
    for (let i = 0; i < this.n; i++) {
      const z = this.zs[i];
      const f = clamp(1 - (z - rearZ) / maxLen, 0, 1);
      const k = f * f;
      const o = i * 6;
      const h = 0.18 + 0.4 * this.width;
      this.pos[o] = this.xs[i];
      this.pos[o + 1] = this.ys[i] + 0.35;
      this.pos[o + 2] = z;
      this.pos[o + 3] = this.xs[i];
      this.pos[o + 4] = this.ys[i] + 0.35 + h * (0.4 + 0.6 * f);
      this.pos[o + 5] = z;
      this.col[o] = r * k * 0.6;
      this.col[o + 1] = g * k * 0.6;
      this.col[o + 2] = b * k * 0.6;
      this.col[o + 3] = r * k;
      this.col[o + 4] = g * k;
      this.col[o + 5] = b * k;
    }
    (this.geo.attributes.position as THREE.BufferAttribute).needsUpdate = true;
    (this.geo.attributes.color as THREE.BufferAttribute).needsUpdate = true;
  }
}

// ---------------- Engine ----------------
export class Engine {
  container: HTMLElement;
  cb: Callbacks;
  renderer: THREE.WebGLRenderer;
  scene = new THREE.Scene();
  camera: THREE.PerspectiveCamera;
  models: Models;
  hud: Hud = {};

  state: GameState = 'menu';
  menuView: 'title' | 'garage' = 'title';
  bikeDef: BikeDef = getBike('volt');
  bike!: BikeModel;

  private raf = 0;
  private last = 0;
  private disposed = false;
  private pixelRatio = 1;
  private maxPR = 2;
  private frameAcc = 0;
  private frameCount = 0;

  private glowTex: THREE.Texture;
  private roadMat: THREE.MeshLambertMaterial;
  private tileTopGeo: THREE.PlaneGeometry;
  private groundMat: THREE.MeshLambertMaterial;
  private groundTex: THREE.Texture;
  private skyMat: THREE.ShaderMaterial;
  private sunMat: THREE.ShaderMaterial;
  private hemi!: THREE.HemisphereLight;
  private sun!: THREE.DirectionalLight;
  private ambient!: THREE.AmbientLight;
  private sunDisc!: THREE.Mesh;
  private sunGlow!: THREE.Sprite;
  private clouds: THREE.Sprite[] = [];
  private tod = 0;
  private todApplied = -1;
  timePref: TimePref = 'cycle';

  private tiles: Tile[] = [];
  private tilePools = new Map<TileVariant, THREE.Group[]>();
  private decals: Decal[] = [];
  private decalPools = new Map<DecalKind, THREE.Group[]>();
  private lips: Lip[] = [];
  private lipPool: THREE.Group[] = [];
  private litSeq = 0;
  private padT = 0;
  private needLanding = 0;
  private bridgeLeft = 0;
  private tunnelLeft = 0;
  private chunkZ0 = 0;
  private gaps: Gap[] = [];
  private obstacles: Obstacle[] = [];
  private obPool = new Map<ObKind, THREE.Group[]>();
  private coins: Coin[] = [];
  private coinMesh: THREE.InstancedMesh;
  private coinRing: THREE.InstancedMesh;
  private readonly MAX_COINS = 160;
  private powers: Power[] = [];
  private powerPool = new Map<PowerKind, THREE.Group[]>();
  private buildings: Scenery[] = [];
  private arches: Scenery[] = [];
  private buildingMats: THREE.MeshLambertMaterial[] = [];
  private particles = new Particles();
  private trail = new Trail();
  private speedLines: THREE.LineSegments;
  private speedPos: Float32Array;
  private readonly SL = 70;
  private dummy = new THREE.Object3D();

  // world
  private spawnZ = 18;
  private genDist = 0;
  private nextPowerGen = 340;
  private chunkCount = 0;

  // player
  private lane = 1;
  private prevLane = 1;
  private px = 0;
  private py = 0;
  private vy = 0;
  private vx = 0;
  private grounded = true;
  private coyote = 0;
  private jumpBuf = 0;
  private duckT = 0;
  private squash = 0;
  private falling = false;
  private invuln = 0;
  private bumpT = 0;

  // run
  speed = BASE_SPEED;
  private effSpeed = BASE_SPEED;
  private time = 0;
  private score = 0;
  private distance = 0;
  private coinsRun = 0;
  private nearMisses = 0;
  private combo = 0;
  private maxCombo = 0;
  private comboT = 0;
  private coinChain = 0;
  private coinChainT = 0;
  private magnetT = 0;
  private boostT = 0;
  private multiT = 0;
  private shield = false;
  private deathT = 0;

  // fx
  private trauma = 0;
  private timeScale = 1;
  private slowT = 0;
  private flashAmt = 0;
  private camPos = new THREE.Vector3(0, 3, 7);
  private camLook = new THREE.Vector3(0, 1, -10);
  private menuT = 0;
  private hudCache: Record<string, string> = {};
  private tmpV = new THREE.Vector3();

  // input
  private touchStart: { x: number; y: number; t: number; used: boolean; id: number; armed: boolean } | null = null;
  private lastSwipeAt = 0;

  constructor(container: HTMLElement, cb: Callbacks) {
    this.container = container;
    this.cb = cb;
    const isMobile = /Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent) || window.innerWidth < 760;
    this.maxPR = isMobile ? 1.5 : 2;
    this.pixelRatio = Math.min(window.devicePixelRatio || 1, this.maxPR);
    this.renderer = new THREE.WebGLRenderer({ antialias: !isMobile, powerPreference: 'high-performance' });
    this.renderer.setPixelRatio(this.pixelRatio);
    this.renderer.setSize(container.clientWidth, container.clientHeight);
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    container.appendChild(this.renderer.domElement);
    this.renderer.domElement.style.touchAction = 'none';

    this.camera = new THREE.PerspectiveCamera(64, container.clientWidth / container.clientHeight, 0.1, 1200);
    this.scene.background = new THREE.Color(0xa8cbe8);
    this.scene.fog = new THREE.Fog(0xc8dcec, 60, 430);

    this.hemi = new THREE.HemisphereLight(0xbcd8f2, 0x6a6a58, 1.5);
    this.scene.add(this.hemi);
    this.sun = new THREE.DirectionalLight(0xfff4dd, 2.1);
    this.sun.position.set(-40, 70, 30);
    this.scene.add(this.sun);
    this.ambient = new THREE.AmbientLight(0xffffff, 0.3);
    this.scene.add(this.ambient);

    this.glowTex = TX.makeGlowTexture();
    this.models = new Models(this.glowTex, TX.makeHazardTexture(), [0, 1, 2, 3].map((i) => TX.makeSignTexture(i)));

    // ---- sky dome: day -> sunset -> night ----
    this.skyMat = new THREE.ShaderMaterial({
      uniforms: {
        uTop: { value: new THREE.Color(0x2f7fd4) },
        uBottom: { value: new THREE.Color(0xd7e9f7) },
        uNight: { value: 0 },
        uTime: { value: 0 },
      },
      side: THREE.BackSide,
      depthWrite: false,
      fog: false,
      vertexShader: `varying vec3 vP; void main(){ vP=position; gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0); }`,
      fragmentShader: `
        uniform vec3 uTop; uniform vec3 uBottom; uniform float uNight; uniform float uTime;
        varying vec3 vP;
        float hash(vec2 p){ return fract(sin(dot(p, vec2(127.1,311.7)))*43758.5453); }
        void main(){
          vec3 n = normalize(vP);
          float h = clamp(n.y*1.2+0.1, 0.0, 1.0);
          vec3 col = mix(uBottom, uTop, pow(h, 0.7));
          if(uNight > 0.02){
            vec2 g = floor(n.xz*190.0 + n.y*120.0);
            float s = hash(g);
            float tw = step(0.9972, s) * (0.5+0.5*sin(uTime*2.2+s*140.0));
            col += vec3(tw) * uNight * smoothstep(0.0,0.35,h);
          }
          gl_FragColor = vec4(col, 1.0);
        }`,
    });
    const sky = new THREE.Mesh(new THREE.SphereGeometry(800, 26, 18), this.skyMat);
    sky.renderOrder = -10;
    sky.frustumCulled = false;
    this.scene.add(sky);

    // road resources (asphalt responds to daylight, neon paint wakes up at night)
    const asphalt = TX.makeAsphaltMap();
    const asphaltE = TX.makeAsphaltEmissive();
    this.roadMat = this.models.lit(
      new THREE.MeshLambertMaterial({ map: asphalt, emissiveMap: asphaltE, emissive: 0xffffff, emissiveIntensity: 0 })
    );
    this.tileTopGeo = new THREE.PlaneGeometry(ROAD_HALF * 2, TILE_LEN);
    this.tileTopGeo.rotateX(-Math.PI / 2);

    // terrain far below the elevated highway
    const gmap = TX.makeGroundMap();
    gmap.repeat.set(90, 90);
    const gem = TX.makeGroundEmissive();
    gem.repeat.set(90, 90);
    this.groundTex = gmap;
    this.groundMat = this.models.lit(
      new THREE.MeshLambertMaterial({ map: gmap, emissiveMap: gem, emissive: 0xffffff, emissiveIntensity: 0, color: 0xc6d6ae })
    );
    const ground = new THREE.Mesh(new THREE.PlaneGeometry(1100, 1100), this.groundMat);
    ground.rotation.x = -Math.PI / 2;
    ground.position.set(0, -11, -240);
    this.scene.add(ground);

    // sun / moon disc: clean by day, striped synthwave after dark
    this.sunMat = new THREE.ShaderMaterial({
      uniforms: { uTime: { value: 0 }, uNight: { value: 0 } },
      transparent: true,
      depthWrite: false,
      fog: false,
      vertexShader: `varying vec2 vUv; void main(){ vUv=uv; gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);} `,
      fragmentShader: `
        uniform float uTime; uniform float uNight; varying vec2 vUv;
        void main(){
          vec2 p = vUv-0.5; float r = length(p);
          if(r>0.5) discard;
          float t = vUv.y;
          vec3 dayCol = vec3(1.0,0.99,0.93);
          vec3 nightCol = mix(vec3(1.0,0.12,0.55), vec3(1.0,0.86,0.25), smoothstep(0.1,0.95,t));
          vec3 col = mix(dayCol, nightCol, uNight);
          float band = fract(t*13.0 + uTime*0.25);
          float thr = (0.56 - t)*1.5*uNight;
          if(t<0.56 && band < thr) discard;
          float edge = smoothstep(0.5,0.46,r);
          gl_FragColor = vec4(col, edge);
        }`,
    });
    this.sunDisc = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), this.sunMat);
    this.sunDisc.position.set(0, 90, -620);
    this.sunDisc.scale.setScalar(70);
    this.sunDisc.frustumCulled = false;
    this.sunDisc.renderOrder = -9;
    this.scene.add(this.sunDisc);
    this.sunGlow = new THREE.Sprite(
      new THREE.SpriteMaterial({
        map: this.glowTex,
        color: 0xfff0c0,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
        fog: false,
        opacity: 0.55,
      })
    );
    this.sunGlow.scale.set(320, 320, 1);
    this.sunGlow.position.copy(this.sunDisc.position);
    this.sunGlow.renderOrder = -8;
    this.scene.add(this.sunGlow);

    // drifting clouds
    const cloudTex = TX.makeCloudTexture();
    for (let i = 0; i < 9; i++) {
      const s = new THREE.Sprite(
        new THREE.SpriteMaterial({
          map: cloudTex,
          color: 0xffffff,
          transparent: true,
          opacity: 0.75,
          depthWrite: false,
          fog: false,
        })
      );
      const a = (i / 9) * Math.PI * 2;
      s.position.set(Math.sin(a) * rand(180, 460), rand(70, 190), -Math.abs(Math.cos(a)) * rand(240, 620) - 120);
      s.scale.set(rand(150, 320), rand(50, 100), 1);
      s.userData.drift = rand(0.6, 2.2);
      this.clouds.push(s);
      this.scene.add(s);
    }

    // coins
    const coinGeo = new THREE.CylinderGeometry(0.42, 0.42, 0.12, 6);
    coinGeo.rotateX(Math.PI / 2);
    this.coinMesh = new THREE.InstancedMesh(coinGeo, new THREE.MeshBasicMaterial({ color: 0xffd23f }), this.MAX_COINS);
    this.coinMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.coinMesh.frustumCulled = false;
    this.coinMesh.count = 0;
    this.scene.add(this.coinMesh);
    const ringGeo = new THREE.TorusGeometry(0.56, 0.05, 4, 6);
    this.coinRing = new THREE.InstancedMesh(
      ringGeo,
      new THREE.MeshBasicMaterial({ color: 0xfff3b0, transparent: true, opacity: 0.85, blending: THREE.AdditiveBlending }),
      this.MAX_COINS
    );
    this.coinRing.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.coinRing.frustumCulled = false;
    this.coinRing.count = 0;
    this.scene.add(this.coinRing);

    // scenery: facades lit by the sun by day, windows glowing after dark
    for (let i = 0; i < 4; i++) {
      const rep = i % 2 ? 2 : 3;
      const f = TX.makeFacadeTexture(i + 1);
      f.repeat.set(rep, i < 2 ? 7 : 11);
      const w = TX.makeWindowTexture(i + 1);
      w.repeat.set(rep, i < 2 ? 7 : 11);
      this.buildingMats.push(
        this.models.lit(
          new THREE.MeshLambertMaterial({ map: f, emissiveMap: w, emissive: 0xffffff, emissiveIntensity: 0 })
        )
      );
    }
    for (let i = 0; i < 46; i++) {
      const g = new THREE.Group();
      const b: Scenery = { group: g, z: 20 - (i / 46) * 400, depth: 6 };
      this.randomizeBuilding(b, i % 2 === 0 ? -1 : 1);
      this.buildings.push(b);
      this.scene.add(g);
    }
    // roadside billboards
    for (let i = 0; i < 7; i++) {
      const g = new THREE.Group();
      const side = i % 2 ? -1 : 1;
      const bt = TX.makeBillboardTexture(i);
      const panelMat = this.models.lit(
        new THREE.MeshLambertMaterial({ map: bt, emissiveMap: bt, emissive: 0xffffff, emissiveIntensity: 0 })
      );
      const panel = new THREE.Mesh(new THREE.BoxGeometry(8, 4, 0.24), panelMat);
      panel.position.set(side * 12.5, 8.4, 0);
      panel.rotation.y = -side * 0.3;
      g.add(panel);
      const frame = new THREE.Mesh(new THREE.BoxGeometry(8.4, 4.4, 0.16), this.models.darkSteel);
      frame.position.set(side * 12.5, 8.4, side * 0.1);
      frame.rotation.y = -side * 0.3;
      g.add(frame);
      for (const dz of [-2.6, 2.6]) {
        const post = new THREE.Mesh(new THREE.BoxGeometry(0.3, 6.6, 0.3), this.models.steel);
        post.position.set(side * 12.5 + dz * 0.9, 3.3, 0);
        g.add(post);
      }
      const a: Scenery = { group: g, z: -20 - i * 56, depth: 1 };
      g.position.z = a.z;
      this.arches.push(a);
      this.scene.add(g);
    }

    // speed lines
    this.speedPos = new Float32Array(this.SL * 6);
    for (let i = 0; i < this.SL; i++) this.resetSpeedLine(i, rand(-90, 10));
    const slGeo = new THREE.BufferGeometry();
    slGeo.setAttribute('position', new THREE.BufferAttribute(this.speedPos, 3).setUsage(THREE.DynamicDrawUsage));
    this.speedLines = new THREE.LineSegments(
      slGeo,
      new THREE.LineBasicMaterial({ color: 0xbff8ff, transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false })
    );
    this.speedLines.frustumCulled = false;
    this.scene.add(this.speedLines);

    this.scene.add(this.particles.points);
    this.scene.add(this.trail.mesh);

    this.setBike('volt');
    // initial road
    while (this.spawnZ > -SPAWN_DIST) this.genPlain();

    this.bindInput();
    window.addEventListener('resize', this.onResize);
    document.addEventListener('visibilitychange', this.onVis);
    this.onResize();
    this.last = performance.now();
    this.raf = requestAnimationFrame(this.loop);
  }

  // ---------- public API ----------
  setHud(h: Hud) {
    this.hud = h;
    this.hudCache = {};
  }

  setMenuView(v: 'title' | 'garage') {
    this.menuView = v;
  }

  setTimePref(p: TimePref) {
    this.timePref = p;
    this.todApplied = -1;
  }

  setBike(id: string) {
    const def = getBike(id);
    if (this.bike && this.bikeDef.id === def.id) return;
    this.bikeDef = def;
    if (this.bike) this.scene.remove(this.bike.group);
    this.bike = buildBike(def, this.glowTex, (mat, mesh, maxOpacity) => this.models.registerNight(mat, mesh, maxOpacity));
    this.scene.add(this.bike.group);
    this.trail.color.set(def.glow);
    this.trail.reset(this.px, this.py);
  }

  start() {
    sfx.unlock();
    // clear world ahead
    for (const o of this.obstacles) this.releaseOb(o);
    this.obstacles = [];
    for (const p of this.powers) this.releasePower(p);
    this.powers = [];
    this.coins = [];
    this.gaps = [];
    this.tiles = this.tiles.filter((t) => {
      if (t.z < -24) {
        this.releaseTile(t);
        return false;
      }
      return true;
    });
    let far = 18;
    for (const t of this.tiles) far = Math.min(far, t.z - TILE_LEN / 2);
    this.spawnZ = far;
    this.genDist = 0;
    this.chunkCount = 0;
    this.nextPowerGen = 330;
    this.clearTrackProps();
    this.needLanding = 0;
    this.bridgeLeft = 0;
    this.tunnelLeft = 0;
    this.padT = 0;

    this.lane = 1;
    this.prevLane = 1;
    this.px = 0;
    this.py = 0;
    this.vy = 0;
    this.vx = 0;
    this.grounded = true;
    this.duckT = 0;
    this.falling = false;
    this.invuln = 0;
    this.speed = BASE_SPEED;
    this.effSpeed = BASE_SPEED;
    this.time = 0;
    this.score = 0;
    this.distance = 0;
    this.coinsRun = 0;
    this.nearMisses = 0;
    this.combo = 0;
    this.maxCombo = 0;
    this.comboT = 0;
    this.magnetT = 0;
    this.boostT = 0;
    this.multiT = 0;
    this.shield = this.bikeDef.startShield;
    this.deathT = 0;
    this.timeScale = 1;
    this.slowT = 0;
    this.trauma = 0.2;
    this.bike.group.visible = true;
    this.bike.group.rotation.set(0, 0, 0);
    this.bike.body.rotation.set(0, 0, 0);
    this.particles.clear();
    this.trail.reset(0, 0);
    this.hudCache = {};
    this.setState('playing');
    sfx.go();
    sfx.startMusic();
    this.popup('GO!', '#22f3ff', undefined, true);
    this.flash('#22f3ff', 0.35);
    this.last = performance.now();
  }

  pause() {
    if (this.state !== 'playing') return;
    this.setState('paused');
    sfx.stopMusic();
  }

  resume() {
    if (this.state !== 'paused') return;
    this.last = performance.now();
    this.setState('playing');
    sfx.startMusic();
  }

  toMenu() {
    for (const o of this.obstacles) this.releaseOb(o);
    this.obstacles = [];
    for (const p of this.powers) this.releasePower(p);
    this.powers = [];
    this.coins = [];
    this.gaps = [];
    // refill with plain road
    this.tiles = this.tiles.filter((t) => {
      if (t.z < -24) {
        this.releaseTile(t);
        return false;
      }
      return true;
    });
    let far = 18;
    for (const t of this.tiles) far = Math.min(far, t.z - TILE_LEN / 2);
    this.spawnZ = far;
    this.clearTrackProps();
    this.needLanding = 0;
    this.bridgeLeft = 0;
    this.tunnelLeft = 0;
    this.padT = 0;
    this.px = 0;
    this.py = 0;
    this.lane = 1;
    this.falling = false;
    this.bike.group.visible = true;
    this.bike.group.rotation.set(0, 0, 0);
    this.bike.body.rotation.set(0, 0, 0);
    this.shield = false;
    this.magnetT = this.boostT = this.multiT = 0;
    this.timeScale = 1;
    sfx.stopMusic();
    this.setState('menu');
    this.last = performance.now();
  }

  dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.raf);
    window.removeEventListener('resize', this.onResize);
    document.removeEventListener('visibilitychange', this.onVis);
    window.removeEventListener('keydown', this.onKey);
    const el = this.renderer.domElement;
    el.removeEventListener('pointerdown', this.onPointerDown);
    el.removeEventListener('pointermove', this.onPointerMove);
    el.removeEventListener('pointerup', this.onPointerUp);
    el.removeEventListener('pointercancel', this.onPointerUp);
    sfx.stopMusic();
    this.renderer.dispose();
    el.remove();
  }

  // ---------- input ----------
  private bindInput() {
    window.addEventListener('keydown', this.onKey);
    const el = this.renderer.domElement;
    el.addEventListener('pointerdown', this.onPointerDown);
    el.addEventListener('pointermove', this.onPointerMove);
    el.addEventListener('pointerup', this.onPointerUp);
    el.addEventListener('pointercancel', this.onPointerUp);
  }

  private onKey = (e: KeyboardEvent) => {
    if (this.state !== 'playing') return;
    const k = e.code;
    if (k === 'Escape' || k === 'KeyP') {
      e.preventDefault();
      this.pause();
      return;
    }
    if (e.repeat) return;
    if (k === 'ArrowLeft' || k === 'KeyA') this.moveLane(-1);
    else if (k === 'ArrowRight' || k === 'KeyD') this.moveLane(1);
    else if (k === 'ArrowUp' || k === 'KeyW' || k === 'Space') this.jump();
    else if (k === 'ArrowDown' || k === 'KeyS') this.duck();
    else return;
    e.preventDefault();
  };

  private onPointerDown = (e: PointerEvent) => {
    if (this.state !== 'playing') return;
    this.touchStart = { x: e.clientX, y: e.clientY, t: performance.now(), used: false, id: e.pointerId, armed: true };
  };
  private onPointerMove = (e: PointerEvent) => {
    const s = this.touchStart;
    if (!s || s.id !== e.pointerId || this.state !== 'playing') return;
    const dx = e.clientX - s.x;
    const dy = e.clientY - s.y;
    const th = Math.max(26, Math.min(window.innerWidth, window.innerHeight) * 0.055);
    // One gesture = ONE lane change. The anchor never moves, so a long swipe
    // cannot fire twice; the finger must return near the anchor to re-arm.
    if (!s.armed) {
      if (Math.abs(dx) < th * 0.45 && Math.abs(dy) < th * 0.45) s.armed = true;
      return;
    }
    if (Math.abs(dx) < th && Math.abs(dy) < th) return;
    const now = performance.now();
    if (now - this.lastSwipeAt < 70) return;
    this.lastSwipeAt = now;
    s.armed = false;
    s.used = true;
    if (Math.abs(dx) > Math.abs(dy)) this.moveLane(dx > 0 ? 1 : -1);
    else if (dy < 0) this.jump();
    else this.duck();
  };
  private onPointerUp = (e: PointerEvent) => {
    const s = this.touchStart;
    if (!s || s.id !== e.pointerId) return;
    if (!s.used && this.state === 'playing' && performance.now() - s.t < 300) this.jump();
    this.touchStart = null;
  };

  private moveLane(dir: number) {
    const nl = this.lane + dir;
    if (nl < 0 || nl > 2) {
      this.trauma = Math.min(1, this.trauma + 0.12);
      sfx.bump();
      this.vx = dir * 6;
      return;
    }
    this.prevLane = this.lane;
    this.lane = nl;
    sfx.lane();
    // side sparks
    for (let i = 0; i < 6; i++)
      this.particles.emit(this.px - dir * 0.3, this.py + 0.1, 0.6, -dir * rand(2, 6), rand(1, 3), rand(2, 6), this.bikeDef.glow, 0.18, 0.35, 8);
  }

  private jump() {
    if (this.falling) return;
    if (this.grounded || this.coyote > 0) {
      this.doJump();
    } else {
      this.jumpBuf = 0.14;
    }
  }

  private doJump(hMul = 1) {
    const h = 2.35 * this.bikeDef.jump * hMul;
    this.vy = Math.sqrt(2 * GRAVITY * h);
    this.grounded = false;
    this.coyote = 0;
    this.jumpBuf = 0;
    this.duckT = 0;
    this.squash = -0.6;
    sfx.jump();
    this.particles.burst(this.px, 0.1, 0.5, 10, this.bikeDef.glow, 5, 0.25, 0.4, 6, 2);
  }

  /** Boost pad: short speed surge, points and a burst of sparks. */
  private hitPad(x: number) {
    this.padT = 1.6;
    this.score += 40 * (this.multiT > 0 ? 2 : 1);
    sfx.pad();
    this.trauma = Math.min(1, this.trauma + 0.3);
    this.flash('#ff2bd6', 0.35);
    this.popup('BOOST PAD +40', '#ff2bd6', this.tmpV.set(x, 1.4, 0));
    for (let i = 0; i < 34; i++)
      this.particles.emit(
        x + rand(-0.9, 0.9),
        rand(0.05, 0.5),
        rand(-1, 1),
        rand(-3, 3),
        rand(1, 6),
        rand(6, 16),
        Math.random() < 0.5 ? 0xff2bd6 : 0xffe14d,
        0.32,
        0.5
      );
  }

  /** Launch ramp: big free air, bonus points if you stay airborne. */
  private hitRamp(x: number) {
    if (!this.grounded && this.py > 0.4) return;
    this.grounded = false;
    this.py = Math.max(this.py, 0);
    this.doJump(1.75);
    this.score += 60 * (this.multiT > 0 ? 2 : 1);
    sfx.ramp();
    this.trauma = Math.min(1, this.trauma + 0.35);
    this.flash('#ffe14d', 0.4);
    this.popup('LAUNCH! +60', '#ffe14d', this.tmpV.set(x, 1.8, 0), true);
    this.particles.burst(x, 0.2, 0.4, 40, 0xffe14d, 11, 0.35, 0.6, 12, 4);
  }

  private duck() {
    if (this.falling) return;
    if (!this.grounded) {
      this.vy = Math.min(this.vy, -26);
      this.duckT = 0.75;
    } else {
      this.duckT = 0.75;
      sfx.duck();
    }
  }

  private onResize = () => {
    const w = this.container.clientWidth;
    const h = this.container.clientHeight;
    this.renderer.setSize(w, h);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.particles.mat.uniforms.uScale.value = h * this.pixelRatio * 0.55;
    if (this.state === 'paused' || this.state === 'over') this.renderer.render(this.scene, this.camera);
  };

  private onVis = () => {
    if (document.hidden && this.state === 'playing') this.pause();
  };

  private setState(s: GameState) {
    this.state = s;
    this.cb.onState(s);
  }

  // ---------- pools ----------
  private getOb(kind: ObKind): THREE.Group {
    const pool = this.obPool.get(kind);
    const m = pool && pool.length ? pool.pop()! : this.models.build(kind);
    m.visible = true;
    m.rotation.set(0, 0, 0);
    m.scale.set(1, 1, 1);
    if (!m.parent) this.scene.add(m);
    return m;
  }
  private releaseOb(o: Obstacle) {
    o.mesh.visible = false;
    let pool = this.obPool.get(o.kind);
    if (!pool) {
      pool = [];
      this.obPool.set(o.kind, pool);
    }
    pool.push(o.mesh);
  }
  private releasePower(p: Power) {
    p.mesh.visible = false;
    let pool = this.powerPool.get(p.kind);
    if (!pool) {
      pool = [];
      this.powerPool.set(p.kind, pool);
    }
    pool.push(p.mesh);
  }
  private buildTile(variant: TileVariant): THREE.Group {
    const g = new THREE.Group();
    const m = this.models;
    g.add(new THREE.Mesh(this.tileTopGeo, this.roadMat));
    if (variant !== 'bridge') g.add(new THREE.Mesh(m.kerbGeo, m.kerbMat));
    const strip = new THREE.Mesh(m.neonStripGeo, m.neonStripMat);
    g.add(strip);
    const side = this.litSeq++ % 2 === 0 ? -1 : 1;
    if (variant === 'roadLit') g.add(m.buildLamp(side));
    else if (variant === 'roadTree') {
      const tree = m.buildTree(this.litSeq % 3);
      tree.position.set(side * (ROAD_HALF + rand(2.2, 6.5)), -0.2, rand(-2, 2));
      g.add(tree);
      if (this.litSeq % 2 === 0) g.add(m.buildLamp(-side));
    } else if (variant === 'tunnel') g.add(m.buildTunnel());
    else if (variant === 'bridge') {
      g.add(m.buildBridge());
      g.add(m.buildLamp(side));
    }
    return g;
  }

  private addTile(zc: number, variant: TileVariant = 'road') {
    let pool = this.tilePools.get(variant);
    if (!pool) {
      pool = [];
      this.tilePools.set(variant, pool);
    }
    let g = pool.pop();
    if (!g) {
      g = this.buildTile(variant);
      this.scene.add(g);
    }
    g.visible = true;
    g.position.set(0, 0, zc);
    this.tiles.push({ mesh: g, z: zc, variant });
  }
  private releaseTile(t: Tile) {
    t.mesh.visible = false;
    this.tilePools.get(t.variant)?.push(t.mesh);
  }

  private addDecal(kind: DecalKind, lane: number, z: number) {
    let pool = this.decalPools.get(kind);
    if (!pool) {
      pool = [];
      this.decalPools.set(kind, pool);
    }
    let m = pool.pop();
    if (!m) {
      m = this.models.buildDecal(kind);
      this.scene.add(m);
    }
    m.visible = true;
    m.position.set(LANE_X[lane], 0, z);
    this.decals.push({ kind, mesh: m, x: LANE_X[lane], z, dead: false });
  }
  private releaseDecal(d: Decal) {
    d.mesh.visible = false;
    this.decalPools.get(d.kind)?.push(d.mesh);
  }

  private addLip(z: number, side: number) {
    let m = this.lipPool.pop();
    if (!m) {
      m = this.models.buildGapLip(side);
      this.scene.add(m);
    } else {
      m.scale.z = side;
    }
    m.visible = true;
    m.position.set(0, 0, z);
    this.lips.push({ mesh: m, z });
  }
  private releaseLip(l: Lip) {
    l.mesh.visible = false;
    this.lipPool.push(l.mesh);
  }

  /** Drops every decal and gap lip that belongs to the previous run. */
  private clearTrackProps() {
    for (const d of this.decals) this.releaseDecal(d);
    this.decals = [];
    for (const l of this.lips) this.releaseLip(l);
    this.lips = [];
  }

  /** Paints an arrow in every currently-safe lane so the path reads instantly. */
  private markSafeLanes(z: number, blocked: number[]) {
    // never spill guides into the previous chunk's hazard row
    const zz = Math.min(z, this.chunkZ0 - 7);
    for (let l = 0; l < 3; l++) if (!blocked.includes(l)) this.addDecal('arrow', l, zz);
  }

  // ---------- generation ----------
  private genPlain() {
    const seq = Math.round(this.spawnZ / TILE_LEN);
    const m = ((seq % 6) + 6) % 6;
    const v: TileVariant = this.tunnelLeft > 0 ? 'tunnel' : m === 0 ? 'roadLit' : m === 3 ? 'roadTree' : 'road';
    if (this.tunnelLeft > 0) this.tunnelLeft--;
    this.addTile(this.spawnZ - TILE_LEN / 2, v);
    this.spawnZ -= TILE_LEN;
  }

  private addOb(kind: ObKind, lane: number, z: number, extra: Partial<Obstacle> = {}) {
    const d = OB_DIMS[kind];
    const mesh = this.getOb(kind);
    const x = kind === 'laserLow' || kind === 'laserHigh' || kind === 'gapEdge' ? 0 : LANE_X[lane];
    const o: Obstacle = {
      kind,
      mesh,
      x,
      z,
      w: d.w,
      d: d.d,
      y0: d.y0,
      y1: d.y1,
      vz: 0,
      laneA: lane,
      laneB: lane,
      phase: 0,
      passed: false,
      minSep: 99,
      sepType: 0,
      solid: d.solid,
      ...extra,
    };
    mesh.position.set(o.x, 0, o.z);
    this.obstacles.push(o);
    return o;
  }

  private coinLine(lane: number, z: number, n: number, sp: number, y = 0.9) {
    for (let i = 0; i < n; i++) this.coins.push({ x: LANE_X[lane], y, z: z - i * sp, alive: true });
  }
  private coinArc(lane: number, zc: number, n: number, sp: number, h: number) {
    for (let i = 0; i < n; i++) {
      const t = n === 1 ? 0.5 : i / (n - 1);
      const y = 0.9 + Math.sin(t * Math.PI) * h;
      this.coins.push({ x: LANE_X[lane], y, z: zc + ((n - 1) / 2 - i) * sp, alive: true });
    }
  }
  private addPower(kind: PowerKind, lane: number, z: number) {
    const pool = this.powerPool.get(kind);
    const m = pool && pool.length ? pool.pop()! : this.models.buildPower(kind);
    if (!m.parent) this.scene.add(m);
    m.visible = true;
    const p: Power = { kind, mesh: m, x: LANE_X[lane], y: 1.1, z };
    m.position.set(p.x, p.y, p.z);
    this.powers.push(p);
  }

  private otherLane(a: number, b = -1) {
    const opts = [0, 1, 2].filter((l) => l !== a && l !== b);
    return opts[randInt(opts.length)];
  }

  private genChunk() {
    let z0 = this.spawnZ;
    const sp = this.speed;
    const d = clamp((sp - BASE_SPEED) / (MAX_SPEED - BASE_SPEED - 6), 0, 1);
    // runway between hazards always scales with speed
    const S = clamp(sp * (0.95 - d * 0.18), 24, 62);
    let L = round6(S) + 6;
    const gapSlots = new Set<number>();
    let bridgeFrom = -1;
    let painted = false;
    this.chunkCount++;
    this.chunkZ0 = z0;

    // guarantee landing room straight after a gap
    if (this.needLanding > 0) {
      const n = this.needLanding / TILE_LEN;
      for (let i = 0; i < n; i++) this.addTile(z0 - i * TILE_LEN - TILE_LEN / 2, 'bridge');
      this.spawnZ -= this.needLanding;
      this.genDist += this.needLanding;
      z0 = this.spawnZ;
      this.chunkZ0 = z0;
      this.needLanding = 0;
      this.bridgeLeft = 2;
    }

    // intro: coins right away so the first seconds feel rewarding
    if (this.chunkCount === 1) {
      L = 36;
      this.coinLine(1, z0 - 4, 9, 3.4);
    } else {
      type P = { w: number; f: () => void };
      const oz = () => z0 - L + 6;
      const list: P[] = [
        {
          w: 0.6 * (1 - d) + 0.15,
          f: () => {
            L = 30;
            const ln = randInt(3);
            if (Math.random() < 0.5) this.coinLine(ln, z0 - 3, 7, 3.6);
            else {
              this.coinLine(ln, z0 - 3, 4, 3.6);
              this.coinLine(this.otherLane(ln, ln === 1 ? -1 : 1), z0 - 18, 4, 3.6);
            }
          },
        },
        {
          w: 1.3,
          f: () => {
            const a = randInt(3);
            this.addOb('barrier', a, oz());
            if (Math.random() < 0.5) this.coinArc(a, oz(), 5, 2.6, 2.0);
            else this.coinLine(this.otherLane(a), z0 - 4, 6, 3.4);
          },
        },
        {
          w: 1.1,
          f: () => {
            const free = randInt(3);
            for (let l = 0; l < 3; l++) if (l !== free) this.addOb('barrier', l, oz());
            this.coinLine(free, z0 - 6, 6, 3.4);
          },
        },
        {
          w: 0.2 + d * 0.9,
          f: () => {
            for (let l = 0; l < 3; l++) this.addOb('barrier', l, oz());
            this.coinArc(randInt(3), oz(), 5, 2.6, 2.0);
          },
        },
        {
          w: 1.2,
          f: () => {
            const free = randInt(3);
            for (let l = 0; l < 3; l++) if (l !== free) this.addOb('block', l, oz() + 2);
            if (d > 0.45 && Math.random() < 0.6) {
              this.addOb('barrier', free, oz() + 2);
              this.coinArc(free, oz() + 2, 5, 2.6, 2.0);
            } else this.coinLine(free, z0 - 4, 8, 3.2);
          },
        },
        {
          w: 1.0,
          f: () => {
            this.addOb('laserLow', 1, oz());
            this.coinArc(randInt(3), oz(), 5, 2.6, 2.0);
          },
        },
        {
          w: 0.9,
          f: () => {
            this.addOb('laserHigh', 1, oz());
            this.coinLine(randInt(3), oz() + 6, 5, 3, 0.55);
          },
        },
        {
          w: 1.0,
          f: () => {
            const k = sp > 38 && Math.random() < 0.6 ? 2 : 1;
            const rampFirst = sp > 42 && Math.random() < 0.5;
            L = round6(S) + 6 + k * TILE_LEN + (rampFirst ? 12 : 0);
            const slots = L / TILE_LEN;
            const gi = slots - k - 1;
            for (let i = 0; i < k; i++) gapSlots.add(gi + i);
            const near = z0 - gi * TILE_LEN;
            const far = near - k * TILE_LEN;
            this.gaps.push({ z0: far, z1: near });
            bridgeFrom = gi + k;
            this.addLip(near, 1);
            this.addLip(far, -1);
            this.addDecal('warn', 1, near + 5);
            this.addDecal('warn', 1, near + 11);
            if (rampFirst) {
              const ln = randInt(3);
              this.addDecal('ramp', ln, near + 8);
              this.markSafeLanes(near + 8 + Math.min(sp * 0.5, 16), [0, 1, 2].filter((l) => l !== ln));
              this.coinArc(ln, near + 2, 5, 2.6, 2.4);
            }
            this.coinArc(randInt(3), (near + far) / 2, 5 + k, 2.6, 2.1);
            this.needLanding = round6(Math.max(sp * 0.55, 18));
            painted = true;
          },
        },
        {
          w: 0.5 + d * 0.8,
          f: () => {
            const a = randInt(2);
            this.addOb('drone', a, oz(), { laneA: a, laneB: a + 1, phase: Math.random() * 6 });
            this.coinLine(a === 0 ? 2 : 0, z0 - 4, 6, 3.4);
          },
        },
        {
          w: 0.5 + d * 0.9,
          f: () => {
            const a = randInt(3);
            const vz = 12 + d * 14;
            const target = oz();
            // spawn farther so it meets the player at its chunk slot
            const zs = target * ((sp + vz) / sp);
            this.addOb('car', a, zs, { vz });
            this.coinLine(this.otherLane(a), z0 - 4, 6, 3.4);
            this.markSafeLanes(target + clamp(sp * 0.5, 12, 26), [a]);
            painted = true;
          },
        },
        {
          w: d * 1.4,
          f: () => {
            // Truck slalom: ONE lane blocked per row and the blocked lane only ever
            // shifts by one, so no row ever demands a double lane-change.
            const n = 3 + (d > 0.6 ? 1 : 0);
            const step = round6(Math.max(sp * 0.85, 24));
            L = step * n + 12;
            let lane = randInt(3);
            for (let i = 0; i < n; i++) {
              const z = z0 - 10 - i * step;
              const opts = [lane - 1, lane + 1].filter((l) => l >= 0 && l <= 2);
              const nextLane = opts[randInt(opts.length)];
              this.addOb('block', lane, z);
              this.markSafeLanes(z + Math.min(step * 0.62, 16), [lane]);
              const free = [0, 1, 2].filter((l) => l !== lane && l !== nextLane)[0];
              this.coinLine(free, z + 5, 4, 2.6);
              lane = nextLane;
              painted = true;
            }
          },
        },
        {
          w: d * 1.0,
          f: () => {
            // jump then duck
            const step = round6(sp * 0.95);
            L = step * 2 + 12;
            this.addOb('laserLow', 1, z0 - 8);
            this.addOb('laserHigh', 1, z0 - 8 - step);
            this.coinLine(1, z0 - 8 - step + 4, 4, 2.5, 0.55);
          },
        },
        {
          // boost pad runway - pure reward, teaches the pad
          w: 0.9 * (1 - d) + 0.35,
          f: () => {
            L = round6(sp * 0.8) + 12;
            const ln = randInt(3);
            const pz = z0 - L * 0.5;
            this.addDecal('pad', ln, pz);
            this.coinLine(ln, pz + 7, 8, 3.2);
            this.markSafeLanes(pz + 12, [0, 1, 2].filter((l) => l !== ln));
            painted = true;
          },
        },
        {
          // launch ramp over a full barrier row
          w: 0.5 + d * 0.8,
          f: () => {
            for (let l = 0; l < 3; l++) this.addOb('barrier', l, oz());
            const ln = randInt(3);
            const rz = oz() + Math.max(11, Math.min(sp * 0.45, 20));
            this.addDecal('ramp', ln, rz);
            this.markSafeLanes(rz + 10, [0, 1, 2].filter((l) => l !== ln));
            this.coinArc(ln, rz - 7, 5, 2.6, 2.5);
            painted = true;
          },
        },
        {
          // tunnel run: dressing + two staggered single-lane hazards
          w: 0.35 + d * 0.55,
          f: () => {
            const step = round6(Math.max(sp * 0.8, 24));
            L = step * 2 + 12;
            this.tunnelLeft = L / TILE_LEN;
            const a = randInt(3);
            this.addOb('barrier', a, z0 - 10);
            this.markSafeLanes(z0 - 10 + Math.min(step * 0.6, 16), [a]);
            const b = [0, 1, 2].filter((l) => l !== a)[randInt(2)];
            this.addOb('block', b, z0 - 10 - step);
            this.markSafeLanes(z0 - 10 - step + Math.min(step * 0.62, 16), [b]);
            const free = [0, 1, 2].filter((l) => l !== a && l !== b);
            this.coinLine(free.length ? free[0] : this.otherLane(a), z0 - 10 - step + 6, 4, 2.8);
            painted = true;
          },
        },
      ];
      const total = list.reduce((s, p) => s + p.w, 0);
      let r = Math.random() * total;
      let pick = list[0];
      for (const p of list) {
        r -= p.w;
        if (r <= 0) {
          pick = p;
          break;
        }
      }
      pick.f();

      // power-up drop
      if (this.genDist > this.nextPowerGen && gapSlots.size === 0) {
        this.nextPowerGen = this.genDist + rand(520, 820);
        const kinds: PowerKind[] = ['magnet', 'shield', 'boost', 'multi', 'magnet', 'multi'];
        let k = kinds[randInt(kinds.length)];
        if (k === 'shield' && this.shield) k = 'boost';
        const lane = randInt(3);
        // place right at the chunk start, where the runway is clear
        this.addPower(k, lane, z0 - 3);
      }
    }

    // Paint lane-guide arrows ahead of the chunk's hazard row (unless the
    // pattern already painted its own guides).
    if (!painted) {
      const rowZ = z0 - L + 6;
      const row = this.obstacles.filter(
        (o) => o.solid && o.kind !== 'laserLow' && o.kind !== 'laserHigh' && Math.abs(o.z - rowZ) < 5
      );
      if (row.length) {
        const lanesOf = (o: Obstacle) => (o.kind === 'drone' ? [o.laneA, o.laneB] : [o.laneA]);
        const blocked = new Set(row.flatMap(lanesOf));
        // lanes you can simply ride, else lanes a jump can clear (low obstacles)
        let safe = [0, 1, 2].filter((l) => !blocked.has(l));
        if (!safe.length) safe = [0, 1, 2].filter((l) => row.filter((o) => lanesOf(o).includes(l)).every((o) => o.y1 <= 1.6));
        if (safe.length && safe.length < 3) {
          const guideZ = rowZ + clamp(sp * 0.55, 12, Math.max(12, L - 8));
          this.markSafeLanes(guideZ, [0, 1, 2].filter((l) => !safe.includes(l)));
        }
      }
    }

    const slots = L / TILE_LEN;
    for (let i = 0; i < slots; i++) {
      if (gapSlots.has(i)) continue;
      let v: TileVariant;
      if (bridgeFrom >= 0 && i >= bridgeFrom) v = 'bridge';
      else if (this.bridgeLeft > 0) {
        v = 'bridge';
        this.bridgeLeft--;
      } else if (this.tunnelLeft > 0) {
        v = 'tunnel';
        this.tunnelLeft--;
      } else {
        const m = (i + this.chunkCount * 2) % 6;
        v = m === 0 ? 'roadLit' : m === 3 ? 'roadTree' : 'road';
      }
      this.addTile(z0 - i * TILE_LEN - TILE_LEN / 2, v);
    }
    this.spawnZ -= L;
    this.genDist += L;
  }

  private randomizeBuilding(b: Scenery, side: number) {
    const g = b.group;
    while (g.children.length) g.remove(g.children[0]);
    const w = rand(4, 9);
    const dz = rand(5, 12);
    const h = Math.random() < 0.15 ? rand(45, 75) : rand(8, 40);
    const mat = this.buildingMats[randInt(this.buildingMats.length)];
    const box = new THREE.Mesh(this.models.boxGeo, mat);
    const H = h + 40;
    box.scale.set(w, H, dz);
    box.position.y = (h - 40) / 2;
    g.add(box);
    const x = side * (7.5 + rand(0, 16) + w / 2);
    g.position.set(x, 0, b.z);
    b.depth = dz;
    // vertical signage: unlit housing by day, neon tube after dark
    if (Math.random() < 0.45) {
      const sh = rand(3, Math.min(14, h * 0.6));
      const sx = -side * (w / 2 + 0.22);
      const sy = rand(sh / 2 + 1, h - sh / 2);
      const sz = rand(-dz / 3, dz / 3);
      const housing = new THREE.Mesh(this.models.boxGeo, this.models.darkSteel);
      housing.scale.set(0.3, sh, 0.34);
      housing.position.set(sx, sy, sz);
      g.add(housing);
      const neon = new THREE.Mesh(
        this.models.boxGeo,
        this.models.neonMat(pick([0xff2bd6, 0x35e6ff, 0xffd23f, 0x6dff8a]))
      );
      neon.scale.set(0.16, sh * 0.86, 0.16);
      neon.position.set(sx - side * 0.14, sy, sz);
      g.add(this.models.onlyAtNight(neon));
    }
    // rooftop parapet + plant
    if (Math.random() < 0.6) {
      const top = new THREE.Mesh(this.models.boxGeo, this.models.concrete);
      top.scale.set(w + 0.16, 0.4, dz + 0.16);
      top.position.y = h;
      g.add(top);
    }
    if (Math.random() < 0.4) {
      const plant = new THREE.Mesh(this.models.boxGeo, this.models.steel);
      plant.scale.set(w * rand(0.2, 0.4), rand(0.8, 2.2), dz * rand(0.2, 0.4));
      plant.position.set(rand(-w * 0.2, w * 0.2), h + 1, rand(-dz * 0.2, dz * 0.2));
      g.add(plant);
    }
  }

  private resetSpeedLine(i: number, z: number) {
    const side = Math.random() < 0.5 ? -1 : 1;
    const x = side * rand(1.5, 10);
    const y = rand(-1, 7);
    const o = i * 6;
    this.speedPos[o] = x;
    this.speedPos[o + 1] = y;
    this.speedPos[o + 2] = z;
    this.speedPos[o + 3] = x;
    this.speedPos[o + 4] = y;
    this.speedPos[o + 5] = z - 3;
  }

  // ---------- fx helpers ----------
  private popup(text: string, color: string, at?: THREE.Vector3, big = false) {
    const host = this.hud.popups;
    if (!host) return;
    const el = document.createElement('div');
    el.className = big ? 'popup popup-big' : 'popup';
    el.textContent = text;
    el.style.color = color;
    if (at) {
      this.tmpV.copy(at).project(this.camera);
      el.style.left = `${(this.tmpV.x * 0.5 + 0.5) * 100}%`;
      el.style.top = `${(-this.tmpV.y * 0.5 + 0.5) * 100}%`;
    } else {
      el.style.left = '50%';
      el.style.top = '34%';
    }
    host.appendChild(el);
    window.setTimeout(() => el.remove(), 1100);
  }

  private flash(color: string, amt: number) {
    if (this.hud.flash) this.hud.flash.style.background = `radial-gradient(ellipse at center, transparent 30%, ${color} 120%)`;
    this.flashAmt = Math.max(this.flashAmt, amt);
  }

  private setText(key: string, el: HTMLElement | null | undefined, v: string) {
    if (!el || this.hudCache[key] === v) return;
    this.hudCache[key] = v;
    el.textContent = v;
  }

  // ---------- main loop ----------
  private loop = (now: number) => {
    if (this.disposed) return;
    this.raf = requestAnimationFrame(this.loop);
    const real = Math.min(0.05, (now - this.last) / 1000);
    this.last = now;
    if (this.state === 'paused' || this.state === 'over') {
      // keep a gentle idle while game over, frozen when paused
      if (this.state === 'over') {
        this.particles.update(real, 0);
        this.renderer.render(this.scene, this.camera);
      }
      return;
    }
    this.adaptQuality(real);

    // time scale (slow-mo)
    if (this.slowT > 0) this.slowT -= real;
    else this.timeScale += (1 - this.timeScale) * (1 - Math.exp(-real * 6));
    const dt = real * this.timeScale;

    if (this.state === 'playing') this.updatePlaying(dt, real);
    else if (this.state === 'dying') this.updateDying(dt, real);
    else this.updateMenu(dt);

    const target =
      this.timePref === 'day' ? 0.05 : this.timePref === 'night' ? 1 : clamp(this.distance / 4200, 0, 1);
    this.tod += (target - this.tod) * (1 - Math.exp(-real * 0.7));
    this.applyTod(this.tod);

    this.updateFx(dt, real);
    this.renderer.render(this.scene, this.camera);
  };

  private adaptQuality(real: number) {
    this.frameAcc += real;
    this.frameCount++;
    if (this.frameCount >= 90) {
      const avg = this.frameAcc / this.frameCount;
      if (avg > 1 / 50 && this.pixelRatio > 0.75) {
        this.pixelRatio = Math.max(0.75, this.pixelRatio - 0.25);
        this.renderer.setPixelRatio(this.pixelRatio);
        this.onResize();
      }
      this.frameAcc = 0;
      this.frameCount = 0;
    }
  }

  private moveWorld(dt: number, dz: number) {
    // tiles
    for (let i = this.tiles.length - 1; i >= 0; i--) {
      const t = this.tiles[i];
      t.z += dz;
      t.mesh.position.z = t.z;
      if (t.z - TILE_LEN / 2 > 14) {
        this.releaseTile(t);
        this.tiles.splice(i, 1);
      }
    }
    for (let i = this.gaps.length - 1; i >= 0; i--) {
      const g = this.gaps[i];
      g.z0 += dz;
      g.z1 += dz;
      if (g.z0 > 10) this.gaps.splice(i, 1);
    }
    // torn gap lips
    for (let i = this.lips.length - 1; i >= 0; i--) {
      const l = this.lips[i];
      l.z += dz;
      l.mesh.position.z = l.z;
      const gl = l.mesh.getObjectByName('glow');
      if (gl) gl.scale.y = 0.7 + Math.random() * 0.5;
      if (l.z > 14) {
        this.releaseLip(l);
        this.lips.splice(i, 1);
      }
    }
    // road decals + pad / ramp triggers
    for (let i = this.decals.length - 1; i >= 0; i--) {
      const dc = this.decals[i];
      dc.z += dz;
      dc.mesh.position.z = dc.z;
      if (dc.kind === 'arrow') {
        dc.mesh.position.y = 0.02 + Math.abs(Math.sin(this.menuT * 5 + dc.z * 0.2)) * 0.06;
      }
      const live = this.state === 'playing' && !dc.dead;
      if (live && (dc.kind === 'pad' || dc.kind === 'ramp') && Math.abs(dc.z) < 1.4 && Math.abs(this.px - dc.x) < 1.05 && this.py < 0.75) {
        dc.dead = true;
        if (dc.kind === 'pad') this.hitPad(dc.x);
        else this.hitRamp(dc.x);
      }
      if (dc.dead || dc.z > 12) {
        this.releaseDecal(dc);
        this.decals.splice(i, 1);
      }
    }
    // obstacles
    for (let i = this.obstacles.length - 1; i >= 0; i--) {
      const o = this.obstacles[i];
      o.z += dz + o.vz * dt;
      if (o.kind === 'drone') {
        o.phase += dt * 1.7;
        const t = (Math.sin(o.phase) + 1) / 2;
        o.x = LANE_X[o.laneA] + (LANE_X[o.laneB] - LANE_X[o.laneA]) * t;
        o.mesh.position.y = Math.sin(o.phase * 3) * 0.12;

      } else if (o.kind === 'laserLow' || o.kind === 'laserHigh') {
        const glow = o.mesh.getObjectByName('glow');
        if (glow) glow.scale.y = 0.75 + Math.random() * 0.4;
      }
      if (o.kind === 'drone') {
        const spin = o.mesh.getObjectByName('spin');
        if (spin) spin.rotation.y += dt * 34;
      }
      o.mesh.position.x = o.x;
      o.mesh.position.z = o.z;
      if (o.z - o.d / 2 > 16) {
        this.releaseOb(o);
        this.obstacles.splice(i, 1);
      }
    }
    // powers
    for (let i = this.powers.length - 1; i >= 0; i--) {
      const p = this.powers[i];
      p.z += dz;
      p.mesh.position.set(p.x, p.y + Math.sin(this.menuT * 4 + i) * 0.15, p.z);
      p.mesh.rotation.y += dt * 2;
      const shell = p.mesh.getObjectByName('shell');
      if (shell) shell.rotation.x += dt * 1.5;
      if (p.z > 12) {
        this.releasePower(p);
        this.powers.splice(i, 1);
      }
    }
    // coins
    for (const c of this.coins) c.z += dz;
    if (this.coins.length > 0 && (this.coins[0].z > 12 || !this.coins[0].alive)) {
      this.coins = this.coins.filter((c) => c.alive && c.z < 12);
    }
    // scenery
    for (const b of this.buildings) {
      b.z += dz;
      b.group.position.z = b.z;
      if (b.z - b.depth / 2 > 25) {
        b.z -= 345;
        this.randomizeBuilding(b, b.group.position.x < 0 ? -1 : 1);
      }
    }
    for (const a of this.arches) {
      a.z += dz;
      a.group.position.z = a.z;
      if (a.z > 20) a.z -= 48 * 8;
    }
    this.groundTex.offset.y += dz / 12.2;
  }

  private updateMenu(dt: number) {
    this.menuT += dt;
    const sp = this.menuView === 'garage' ? 7 : 14;
    this.effSpeed = sp;
    const dz = sp * dt;
    this.moveWorld(dt, dz);
    while (this.spawnZ > -SPAWN_DIST) this.genPlain();
    this.spawnZ += dz;
    this.px += (0 - this.px) * (1 - Math.exp(-dt * 4));
    this.py = 0;
    this.updateBikeVisual(dt);
  }

  private updatePlaying(dt: number, real: number) {
    this.time += dt;
    this.menuT += dt;
    const target = BASE_SPEED + (MAX_SPEED - BASE_SPEED) * (1 - Math.exp(-this.time / 85));
    this.speed = target;
    const boostF = (this.boostT > 0 ? 1.55 : 1) * (this.padT > 0 ? 1.22 : 1);
    this.effSpeed += (this.speed * boostF - this.effSpeed) * (1 - Math.exp(-dt * (this.padT > 0 ? 6 : 3)));
    const dz = this.effSpeed * dt;
    this.distance += dz;
    sfx.intensity = clamp((this.speed - BASE_SPEED) / 25, 0, 1);

    // ---- player ----
    const tx = LANE_X[this.lane];
    const prevX = this.px;
    this.px += (tx - this.px) * (1 - Math.exp(-dt * 15 * this.bikeDef.handling));
    this.vx = (this.px - prevX) / Math.max(dt, 1e-4);

    this.coyote -= dt;
    this.jumpBuf -= dt;
    this.duckT -= dt;
    this.invuln -= dt;
    this.bumpT -= dt;

    const overGap = this.isOverGap();
    if (!this.grounded) {
      this.vy -= GRAVITY * dt * (this.vy < 0 ? 1.15 : 1);
      this.py += this.vy * dt;
      if (this.py <= 0 && this.vy <= 0) {
        if (overGap && this.boostT <= 0) {
          if (this.py < -0.3) this.handleGapFall();
        } else {
          this.py = 0;
          this.vy = 0;
          this.grounded = true;
          this.squash = 1;
          sfx.land();
          this.trauma = Math.min(1, this.trauma + 0.12);
          this.particles.burst(this.px, 0.05, 0.4, 14, this.bikeDef.glow, 6, 0.25, 0.4, 4, 1);
          if (this.jumpBuf > 0) this.doJump();
        }
      }
    } else if (overGap && this.boostT <= 0) {
      this.grounded = false;
      this.coyote = 0.1;
      this.vy = 0;
    }

    if (this.state !== 'playing') return;

    // ---- world ----
    this.moveWorld(dt, dz);
    this.spawnZ += dz;
    while (this.spawnZ > -SPAWN_DIST) this.genChunk();

    // ---- collisions ----
    const halfL = this.bikeDef.length / 2 - 0.2;
    const ph = this.duckT > 0 && this.grounded ? 0.72 : this.duckT > 0 ? 0.8 : 1.45;
    for (let i = this.obstacles.length - 1; i >= 0; i--) {
      const o = this.obstacles[i];
      if (!o.solid) continue;
      const oNear = o.z + o.d / 2;
      const oFar = o.z - o.d / 2;
      if (oNear > -halfL && oFar < halfL) {
        // overlapping in z
        const gx = Math.abs(this.px - o.x) - (o.w / 2 + 0.34);
        const gyOver = this.py - o.y1;
        const gyUnder = o.y0 - (this.py + ph);
        const sep = Math.max(gx, gyOver, gyUnder);
        if (sep < o.minSep) {
          o.minSep = sep;
          o.sepType = sep === gx ? 0 : sep === gyOver ? 1 : 2;
        }
        if (sep < 0) {
          if (this.handleHit(o, gx, oNear + halfL)) {
            this.releaseOb(o);
            this.obstacles.splice(i, 1);
            continue;
          }
          if (this.state !== 'playing') return;
        }
      } else if (!o.passed && oFar >= halfL) {
        o.passed = true;
        const th = NEAR_THRESH[o.kind] ?? 0.6;
        if (o.minSep >= 0 && o.minSep < th) this.nearMiss(o);
      }
    }

    // ---- coins ----
    const magnet = this.magnetT > 0 || this.boostT > 0;
    const pcY = this.py + 0.7;
    let collected = 0;
    for (const c of this.coins) {
      if (!c.alive || c.z < -40) continue;
      const dx = this.px - c.x;
      const dy = pcY - c.y;
      const dzc = -c.z;
      if (magnet && c.z > -16) {
        const dist = Math.sqrt(dx * dx + dy * dy + dzc * dzc) + 0.001;
        const pull = Math.min(1, ((40 + this.effSpeed) * dt) / dist);
        c.x += dx * pull;
        c.y += dy * pull;
        c.z += dzc * pull;
      }
      if (Math.abs(this.px - c.x) < 0.95 && Math.abs(pcY - c.y) < 1.15 && Math.abs(c.z) < 1.3) {
        c.alive = false;
        collected++;
        this.particles.burst(c.x, c.y, c.z, 8, 0xffd23f, 4, 0.3, 0.35, 0, 1);
        this.particles.emit(c.x, c.y, c.z, 0, 2, 0, 0xffffff, 0.9, 0.18);
      }
    }
    if (collected) {
      const mult = this.multiT > 0 ? 2 : 1;
      this.coinsRun += collected;
      this.score += collected * 10 * mult;
      this.coinChain = this.coinChainT > 0 ? this.coinChain + collected : 0;
      this.coinChainT = 0.6;
      sfx.coin(this.coinChain);
      if (this.hud.coins) {
        this.hud.coins.parentElement?.classList.remove('bump');
        void this.hud.coins.parentElement?.offsetWidth;
        this.hud.coins.parentElement?.classList.add('bump');
      }
    }
    this.coinChainT -= dt;

    // ---- powers ----
    for (let i = this.powers.length - 1; i >= 0; i--) {
      const p = this.powers[i];
      if (Math.abs(this.px - p.x) < 1.25 && Math.abs(p.z) < 1.5 && this.py < 2.6) {
        this.activatePower(p.kind);
        this.particles.burst(p.x, p.y, p.z, 40, POWERS[p.kind].color, 9, 0.45, 0.7);
        this.releasePower(p);
        this.powers.splice(i, 1);
      }
    }

    // ---- timers ----
    if (this.padT > 0) {
      this.padT -= dt;
      if (this.padT <= 0) this.popup('SURGE OVER', '#ff8ae6');
    }
    if (this.magnetT > 0) this.magnetT -= dt;
    if (this.multiT > 0) this.multiT -= dt;
    if (this.boostT > 0) {
      this.boostT -= dt;
      if (this.boostT <= 0) {
        this.invuln = 1.2;
        this.popup('BOOST OVER', '#ff2bd6');
        if (this.isOverGap() && this.grounded) this.doJump();
      }
    }
    if (this.comboT > 0) {
      this.comboT -= dt;
      if (this.comboT <= 0) this.combo = 0;
    }

    this.score += dz * 0.5 * (this.multiT > 0 ? 2 : 1) * (1 + Math.min(this.combo, 10) * 0.1);
    this.updateBikeVisual(dt);
    this.updateHud(real);
  }

  private isOverGap() {
    for (const g of this.gaps) if (g.z0 + 0.6 < 0 && g.z1 - 0.6 > 0) return true;
    return false;
  }

  private handleGapFall() {
    if (this.shield) {
      this.shield = false;
      this.vy = Math.sqrt(2 * GRAVITY * 2.6);
      this.py = 0;
      sfx.shieldBreak();
      this.flash('#5dff6a', 0.6);
      this.trauma = Math.min(1, this.trauma + 0.5);
      this.popup('SHIELD SAVE!', '#5dff6a', undefined, true);
      this.particles.burst(this.px, 0.5, 0, 40, 0x5dff6a, 10, 0.4, 0.6);
      return;
    }
    this.falling = true;
    sfx.fall();
    this.die();
  }

  /** returns true if obstacle should be removed */
  private handleHit(o: Obstacle, gx: number, penetration: number): boolean {
    const pos = this.tmpV.set(o.x, 1, o.z);
    if (this.boostT > 0) {
      this.smash(o);
      this.score += 25;
      this.popup('SMASH +25', '#ff2bd6', pos);
      return true;
    }
    if (this.invuln > 0) return false;
    if (this.bumpT > 0 && o.kind !== 'laserLow' && o.kind !== 'laserHigh') return false;
    // lateral scrape: bounce back to previous lane
    const lateral =
      o.kind !== 'laserLow' && o.kind !== 'laserHigh' && Math.abs(this.px - LANE_X[this.lane]) > 0.25 && gx > -0.75 && penetration > 0.7;
    if (lateral && this.bumpT <= 0) {
      const back = this.prevLane === this.lane ? (this.px < o.x ? Math.max(0, this.lane - 1) : Math.min(2, this.lane + 1)) : this.prevLane;
      this.lane = back;
      this.prevLane = back;
      this.bumpT = 0.3;
      this.trauma = Math.min(1, this.trauma + 0.45);
      this.combo = 0;
      sfx.bump();
      this.flash('#ff6a2b', 0.35);
      this.particles.burst(this.px, 0.8, 0, 22, 0xff9a3b, 8, 0.25, 0.4, 10);
      return false;
    }
    if (this.shield) {
      this.shield = false;
      this.invuln = 1.0;
      this.smash(o);
      sfx.shieldBreak();
      this.flash('#5dff6a', 0.7);
      this.popup('SHIELD BROKEN', '#5dff6a', undefined, true);
      return true;
    }
    this.die();
    return false;
  }

  private smash(o: Obstacle) {
    sfx.smash();
    this.trauma = Math.min(1, this.trauma + 0.35);
    const c = o.kind === 'block' ? 0xff2bd6 : o.kind === 'car' ? 0x22f3ff : o.kind === 'laserHigh' ? 0xffe14d : 0xff5a3b;
    this.particles.burst(o.x, 1, o.z, 45, c, 14, 0.4, 0.8, 12, 3);
    this.particles.burst(o.x, 1, o.z, 15, 0xffffff, 10, 0.3, 0.4);
  }

  private nearMiss(o: Obstacle) {
    this.nearMisses++;
    this.combo = Math.min(this.combo + 1, 20);
    this.maxCombo = Math.max(this.maxCombo, this.combo);
    this.comboT = 3.5;
    const mult = this.multiT > 0 ? 2 : 1;
    const pts = 50 * this.combo * mult;
    this.score += pts;
    const label = o.sepType === 1 ? 'CLOSE JUMP' : o.sepType === 2 ? 'SLIDE' : 'NEAR MISS';
    const colors = ['#22f3ff', '#ff2bd6', '#ffe14d', '#5dff6a'];
    const col = colors[Math.min(3, Math.floor((this.combo - 1) / 2))];
    this.popup(`${label}${this.combo > 1 ? ' x' + this.combo : ''}  +${pts}`, col, this.tmpV.set(this.px, 2.2, -1));
    sfx.nearMiss(this.combo);
    this.trauma = Math.min(1, this.trauma + 0.18);
    this.timeScale = 0.55;
    this.slowT = 0.07;
    const side = o.sepType === 0 ? Math.sign(o.x - this.px) || 1 : 0;
    for (let i = 0; i < 18; i++)
      this.particles.emit(this.px + side * 0.5, this.py + rand(0.3, 1.2), rand(-0.5, 0.5), side * rand(1, 4), rand(-1, 3), rand(4, 12), 0xffffff, 0.2, 0.35);
    this.flash(col, 0.18);
  }

  private activatePower(k: PowerKind) {
    const def = POWERS[k];
    const dur = def.duration * this.bikeDef.magnet;
    if (k === 'magnet') this.magnetT = dur;
    else if (k === 'multi') this.multiT = dur;
    else if (k === 'boost') {
      this.boostT = dur;
      this.trauma = Math.min(1, this.trauma + 0.4);
    } else if (k === 'shield') this.shield = true;
    sfx.power();
    this.flash(def.css, 0.55);
    this.popup(def.label + '!', def.css, undefined, true);
    this.score += 100;
  }

  private die() {
    this.setState('dying');
    this.deathT = 0;
    sfx.stopMusic();
    if (!this.falling) {
      sfx.crash();
      this.trauma = 1;
      this.timeScale = 0.2;
      this.slowT = 0.35;
      this.flash('#ffffff', 0.9);
      const g = this.bikeDef.glow;
      this.particles.burst(this.px, 0.8, 0, 110, g, 16, 0.5, 1.2, 14, 4);
      this.particles.burst(this.px, 0.8, 0, 50, 0xff6a2b, 12, 0.6, 0.9, 6, 2);
      this.particles.burst(this.px, 0.8, 0, 30, 0xffffff, 20, 0.3, 0.5);
      this.bike.group.visible = false;
    } else {
      this.flash('#ff2050', 0.5);
      this.trauma = 0.5;
    }
  }

  private updateDying(dt: number, real: number) {
    this.deathT += real;
    this.menuT += dt;
    this.effSpeed *= Math.exp(-dt * (this.falling ? 0.8 : 3));
    const dz = this.effSpeed * dt;
    this.moveWorld(dt, dz);
    this.spawnZ += dz;
    if (this.falling) {
      this.vy -= GRAVITY * dt;
      this.py += this.vy * dt;
      this.bike.group.rotation.x -= dt * 2.5;
      this.bike.group.rotation.z += dt * 1.2;
      this.updateBikeVisual(dt);
    }
    if (this.deathT > (this.falling ? 1.2 : 1.4)) {
      this.setState('over');
      this.cb.onGameOver({
        score: Math.floor(this.score),
        distance: Math.floor(this.distance),
        coins: this.coinsRun,
        nearMisses: this.nearMisses,
        maxCombo: this.maxCombo,
        time: this.time,
        bikeId: this.bikeDef.id,
      });
    }
  }

  private updateBikeVisual(dt: number) {
    const b = this.bike;
    b.group.position.set(this.px, this.py, 0);
    const lean = clamp(-this.vx * 0.045, -0.55, 0.55);
    b.body.rotation.z += (lean - b.body.rotation.z) * (1 - Math.exp(-dt * 18));
    const pitch = this.grounded ? 0 : clamp(this.vy * 0.022, -0.35, 0.35);
    b.body.rotation.x += (pitch - b.body.rotation.x) * (1 - Math.exp(-dt * 10));
    b.body.rotation.y = clamp(-this.vx * 0.012, -0.2, 0.2);
    this.squash *= Math.exp(-dt * 10);
    const ducking = this.duckT > 0;
    const sy = (ducking ? 0.55 : 1) * (1 - this.squash * 0.22);
    const sxz = 1 + this.squash * 0.1;
    b.body.scale.x += (sxz - b.body.scale.x) * 0.5;
    b.body.scale.z += (sxz - b.body.scale.z) * 0.5;
    b.body.scale.y += (sy - b.body.scale.y) * (1 - Math.exp(-dt * 25));
    for (const w of b.wheels) w.rotation.x -= (this.effSpeed * dt) / 0.4;
    b.shield.visible = this.shield;
    if (this.shield) {
      b.shield.rotation.y += dt * 1.5;
      b.shield.rotation.x += dt * 0.7;
      const s = 1 + Math.sin(this.menuT * 6) * 0.04;
      b.shield.scale.set(0.8 * s, 0.8 * s, 1.15 * s);
    }
    const mag = this.magnetT > 0;
    b.magnetRing.visible = mag;
    if (mag) {
      const t = (this.menuT * 1.5) % 1;
      b.magnetRing.scale.setScalar(0.5 + t * 2.2);
      (b.magnetRing.material as THREE.MeshBasicMaterial).opacity = 1 - t;
    }
    const ug = b.underGlow.material as THREE.MeshBasicMaterial;
    ug.opacity = clamp(0.75 - this.py * 0.2, 0.15, 0.75);
    b.group.visible = this.state !== 'dying' || this.falling;
    // invuln blink
    if (this.invuln > 0 && this.state === 'playing') b.body.visible = Math.floor(this.invuln * 14) % 2 === 0;
    else b.body.visible = true;
  }

  /** Applies the time-of-day grade across sky, fog, lights and materials. */
  private applyTod(t: number) {
    if (Math.abs(t - this.todApplied) < 0.004) return;
    this.todApplied = t;
    let i = 0;
    while (i < TOD_KEYS.length - 2 && t > TOD_KEYS[i + 1].t) i++;
    const a = TOD_KEYS[i];
    const b = TOD_KEYS[i + 1];
    const k = clamp((t - a.t) / (b.t - a.t), 0, 1);
    const fog = this.scene.fog as THREE.Fog;
    lerpC(fog.color, a.fog, b.fog, k);
    fog.near = a.fogN + (b.fogN - a.fogN) * k;
    fog.far = a.fogF + (b.fogF - a.fogF) * k;
    (this.scene.background as THREE.Color).copy(fog.color);
    lerpC(this.hemi.color, a.hSky, b.hSky, k);
    lerpC(this.hemi.groundColor, a.hGnd, b.hGnd, k);
    this.hemi.intensity = a.hI + (b.hI - a.hI) * k;
    lerpC(this.sun.color, a.sC, b.sC, k);
    this.sun.intensity = a.sI + (b.sI - a.sI) * k;
    this.ambient.intensity = a.amb + (b.amb - a.amb) * k;
    lerpC(this.roadMat.color, a.road, b.road, k);
    lerpC(this.groundMat.color, a.ground, b.ground, k);
    const u = this.skyMat.uniforms;
    lerpC(u.uTop.value as THREE.Color, a.top, b.top, k);
    lerpC(u.uBottom.value as THREE.Color, a.bot, b.bot, k);
    const night = a.night + (b.night - a.night) * k;
    u.uNight.value = night;
    this.sunMat.uniforms.uNight.value = night;
    this.models.setNight(night);
    const sy = a.sY + (b.sY - a.sY) * k;
    const ss = a.sS + (b.sS - a.sS) * k;
    this.sun.position.set(-40, Math.max(sy, 12), 30);
    this.sunDisc.position.set(0, sy * 1.5, -620);
    this.sunDisc.scale.setScalar(ss);
    this.sunGlow.position.set(0, sy * 1.5, -640);
    this.sunGlow.scale.setScalar(ss * 4.2);
    lerpC(this.sunGlow.material.color, 0xfff0c0, 0xff2bd6, night);
    this.sunGlow.material.opacity = 0.4 + night * 0.45;
    const cloudO = a.cloud + (b.cloud - a.cloud) * k;
    for (const c of this.clouds) {
      c.material.opacity = cloudO * 0.85;
      c.visible = cloudO > 0.05;
    }
  }

  private updateFx(dt: number, real: number) {
    const dz = this.effSpeed * dt;
    this.skyMat.uniforms.uTime.value += real;
    for (const c of this.clouds) {
      c.position.x += c.userData.drift * real;
      if (c.position.x > 520) c.position.x = -520;
    }
    const boosting = (this.boostT > 0 || this.padT > 0) && this.state === 'playing';

    // trail
    this.trail.width = boosting ? 2.2 : 1;
    const showTrail = this.state !== 'dying' || this.falling;
    this.trail.mesh.visible = showTrail;
    if (showTrail) this.trail.update(dz, this.px, this.py, this.bikeDef.length / 2, boosting ? 22 : 12);

    // exhaust / boost sparks
    if (this.state === 'playing' || this.state === 'menu') {
      const rate = boosting ? 3 : this.effSpeed > 40 ? 1 : 0;
      for (let i = 0; i < rate; i++)
        this.particles.emit(
          this.px + rand(-0.25, 0.25),
          this.py + rand(0.2, 0.8),
          this.bikeDef.length / 2,
          rand(-1, 1),
          rand(0, 1.5),
          rand(2, 6),
          boosting ? (Math.random() < 0.5 ? 0xff2bd6 : 0xffffff) : this.bikeDef.glow,
          boosting ? 0.35 : 0.18,
          0.4
        );
      if (this.grounded && this.state === 'playing' && Math.random() < 0.35)
        this.particles.emit(this.px + rand(-0.2, 0.2), 0.05, this.bikeDef.length / 2 - 0.3, rand(-2, 2), rand(1, 3), rand(1, 4), 0xfff1a8, 0.12, 0.25, 12);
    }
    this.particles.update(dt, dz);

    // speed lines
    const slOpacity = clamp((this.effSpeed - 32) / 30, 0, 0.6) + (boosting ? 0.35 : 0);
    const slm = this.speedLines.material as THREE.LineBasicMaterial;
    slm.opacity += (slOpacity - slm.opacity) * 0.1;
    if (slm.opacity > 0.01) {
      const len = this.effSpeed * 0.07;
      for (let i = 0; i < this.SL; i++) {
        const o = i * 6;
        this.speedPos[o + 2] += dz * 1.6;
        this.speedPos[o + 5] = this.speedPos[o + 2] - len;
        if (this.speedPos[o + 5] > 8) this.resetSpeedLine(i, rand(-90, -60));
      }
      (this.speedLines.geometry.attributes.position as THREE.BufferAttribute).needsUpdate = true;
    }

    // coins render
    let n = 0;
    const rot = this.menuT * 3;
    for (const c of this.coins) {
      if (!c.alive || c.z < -SPAWN_DIST - 10 || n >= this.MAX_COINS) continue;
      this.dummy.position.set(c.x, c.y + Math.sin(rot + c.z * 0.3) * 0.08, c.z);
      this.dummy.rotation.set(0, rot, 0);
      this.dummy.scale.setScalar(1);
      this.dummy.updateMatrix();
      this.coinMesh.setMatrixAt(n, this.dummy.matrix);
      this.dummy.rotation.set(0, rot, Math.PI / 6);
      this.dummy.updateMatrix();
      this.coinRing.setMatrixAt(n, this.dummy.matrix);
      n++;
    }
    this.coinMesh.count = n;
    this.coinRing.count = n;
    this.coinMesh.instanceMatrix.needsUpdate = true;
    this.coinRing.instanceMatrix.needsUpdate = true;

    this.sunMat.uniforms.uTime.value += real;

    // camera
    const cam = this.camera;
    let tp: THREE.Vector3, tl: THREE.Vector3, fov: number, k: number;
    if (this.state === 'menu') {
      const garage = this.menuView === 'garage';
      const a = this.menuT * (garage ? 0.45 : 0.18) + 0.6;
      const r = garage ? 4.6 : 6.5;
      tp = new THREE.Vector3(Math.sin(a) * r, garage ? 1.9 : 2.6, Math.cos(a) * r);
      tl = new THREE.Vector3(0, garage ? -0.5 : 1.2, 0);
      fov = 55;
      k = 1 - Math.exp(-real * 3);
    } else {
      const fall = this.falling ? Math.max(this.py, -6) : this.py;
      tp = new THREE.Vector3(this.px * 0.55, 3.0 + fall * 0.45, 6.4 + (boosting ? 1.0 : 0));
      tl = new THREE.Vector3(this.px * 0.75, 1.0 + fall * 0.35, -10);
      fov = 62 + (this.effSpeed - BASE_SPEED) * 0.33 + (boosting ? 8 : 0);
      k = 1 - Math.exp(-real * 9);
    }
    this.camPos.lerp(tp, k);
    this.camLook.lerp(tl, k);
    cam.position.copy(this.camPos);
    // shake
    this.trauma = Math.max(0, this.trauma - real * 1.6);
    const s = this.trauma * this.trauma;
    if (s > 0.0001) {
      cam.position.x += (Math.random() * 2 - 1) * s * 0.7;
      cam.position.y += (Math.random() * 2 - 1) * s * 0.5;
    }
    cam.lookAt(this.camLook);
    if (s > 0.0001) cam.rotation.z += (Math.random() * 2 - 1) * s * 0.06;
    cam.rotation.z += -this.vx * 0.004 * (this.state === 'playing' ? 1 : 0);
    if (Math.abs(cam.fov - fov) > 0.05) {
      cam.fov += (fov - cam.fov) * (1 - Math.exp(-real * 4));
      cam.updateProjectionMatrix();
    }

    // flash overlay
    if (this.hud.flash) {
      this.flashAmt = Math.max(0, this.flashAmt - real * 2.2);
      const v = this.flashAmt.toFixed(3);
      if (this.hudCache.flash !== v) {
        this.hudCache.flash = v;
        this.hud.flash.style.opacity = v;
      }
    }
    if (this.hud.vignette) {
      const v = (this.state === 'playing' ? clamp((this.effSpeed - 30) / 40, 0, 0.8) + (boosting ? 0.3 : 0) : 0).toFixed(2);
      if (this.hudCache.vig !== v) {
        this.hudCache.vig = v;
        this.hud.vignette.style.opacity = v;
      }
    }
  }

  private updateHud(_real: number) {
    const h = this.hud;
    this.setText('score', h.score, Math.floor(this.score).toLocaleString());
    this.setText('coins', h.coins, String(this.coinsRun));
    this.setText('dist', h.dist, `${Math.floor(this.distance)}m`);
    if (h.speed) {
      const v = `${Math.round(clamp((this.effSpeed - 20) / (MAX_SPEED * 1.55 - 20), 0.04, 1) * 100)}%`;
      if (this.hudCache.speed !== v) {
        this.hudCache.speed = v;
        h.speed.style.width = v;
      }
    }
    const comboTxt = this.combo > 1 ? `COMBO x${this.combo}` : '';
    this.setText('combo', h.combo, comboTxt);
    this.setText('mult', h.mult, this.multiT > 0 ? '2X' : '');
    if (h.powers) {
      const vals: Record<PowerKind, number> = {
        magnet: this.magnetT > 0 ? this.magnetT / (POWERS.magnet.duration * this.bikeDef.magnet) : 0,
        boost: this.boostT > 0 ? this.boostT / (POWERS.boost.duration * this.bikeDef.magnet) : 0,
        multi: this.multiT > 0 ? this.multiT / (POWERS.multi.duration * this.bikeDef.magnet) : 0,
        shield: this.shield ? 1 : 0,
      };
      (Object.keys(vals) as PowerKind[]).forEach((k) => {
        const el = h.powers![k];
        if (!el) return;
        const v = vals[k];
        const key = 'p_' + k;
        const sv = v.toFixed(2);
        if (this.hudCache[key] === sv) return;
        this.hudCache[key] = sv;
        el.style.display = v > 0 ? 'flex' : 'none';
        el.style.setProperty('--p', sv);
      });
    }
  }
}
